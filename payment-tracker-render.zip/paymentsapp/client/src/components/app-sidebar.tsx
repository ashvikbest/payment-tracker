import { Link } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { useAuth } from "@/lib/auth";
import {
  LayoutDashboard, Receipt, BookOpen, SquareCheckBig, ShieldCheck,
  ShoppingBag, ShoppingCart, ClipboardList, Landmark, LogOut, CreditCard,
  PlusSquare, BarChart2
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarHeader, SidebarFooter,
  SidebarGroup, SidebarGroupContent, SidebarMenu, SidebarMenuItem, SidebarMenuButton,
  useSidebar,
} from "@/components/ui/sidebar";

const ALL_NAV = [
  { title: "Dashboard",          url: "/",                   icon: LayoutDashboard, roles: ["account","manager","ceo"] },
  { title: "Account Creation",   url: "/account-creation",   icon: PlusSquare,      roles: ["account","manager","ceo"] },
  { title: "Payment Upload",     url: "/payments-form",      icon: Receipt,         roles: ["account","manager","ceo"] },
  { title: "Account Statement",  url: "/account-statement",  icon: BookOpen,        roles: ["account","manager","ceo"] },
  { title: "Manager Approvals",  url: "/manager-approvals",  icon: SquareCheckBig,  roles: ["manager"] },
  { title: "CEO Approvals",      url: "/ceo-approvals",      icon: ShieldCheck,     roles: ["ceo"] },
  { title: "Purchase Form",      url: "/purchase-form",      icon: ShoppingBag,     roles: ["account"] },
  { title: "Purchase Statement", url: "/purchase-statement", icon: ShoppingCart,    roles: ["account","manager","ceo"] },
  { title: "Activity Log",       url: "/activity-log",       icon: ClipboardList,   roles: ["account","manager","ceo"] },
  { title: "Bank Updates",       url: "/bank-updates",       icon: Landmark,        roles: ["account","manager","ceo"] },
  { title: "Reports",            url: "/reports",            icon: BarChart2,       roles: ["account","manager","ceo"] },
];

export function AppSidebar() {
  const { user, logout } = useAuth();
  const [location] = useHashLocation();
  const { setOpenMobile, isMobile, setOpen } = useSidebar();

  const items = ALL_NAV.filter(n => !user || n.roles.includes(user.role));
  const initials = user ? user.username.slice(0, 2).toUpperCase() : "??";

  function handleNavClick() {
    // On mobile: close the drawer; on desktop: collapse the sidebar
    if (isMobile) {
      setOpenMobile(false);
    }
  }

  return (
    <Sidebar>
      {/* Header */}
      <SidebarHeader className="px-4 py-5 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center flex-shrink-0">
            <CreditCard className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-bold text-white leading-tight">Payment Tracker</p>
            <p className="text-xs text-white/50">Mr. Chows</p>
          </div>
        </div>
      </SidebarHeader>

      {/* Nav items */}
      <SidebarContent className="px-2 py-3">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map(item => {
                const isActive = location === item.url ||
                  (item.url !== "/" && location.startsWith(item.url));
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      className={[
                        "gap-3 h-10 text-sm font-medium rounded-lg transition-all duration-150",
                        isActive
                          ? "bg-white/15 text-white font-semibold"
                          : "text-white/70 hover:bg-white/10 hover:text-white",
                      ].join(" ")}
                      data-testid={`nav-${item.url.replace(/\//g, "-")}`}
                    >
                      <Link href={item.url} onClick={handleNavClick}>
                        <item.icon className="w-4 h-4 flex-shrink-0" />
                        <span>{item.title}</span>
                        {isActive && (
                          <span className="ml-auto w-1.5 h-1.5 rounded-full bg-white/80 flex-shrink-0" />
                        )}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {/* Footer */}
      <SidebarFooter className="px-4 py-4 border-t border-sidebar-border">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
            {initials}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-white truncate">{user?.username}</p>
            <p className="text-xs text-white/50 capitalize">{user?.role}</p>
          </div>
          <button
            onClick={logout}
            className="text-white/40 hover:text-white transition-colors"
            data-testid="button-logout"
            title="Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
