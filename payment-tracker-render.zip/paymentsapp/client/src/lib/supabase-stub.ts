// Stub — supabase is not used in this app but is listed as a dependency.
// Aliasing it here prevents localStorage refs from entering the client bundle.
export const createClient = () => ({});
export default { createClient };
