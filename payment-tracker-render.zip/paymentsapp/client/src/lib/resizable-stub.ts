// Stub — react-resizable-panels is unused in this app but present as a template dep.
// Prevents localStorage usage from entering the client bundle.
export const PanelGroup = () => null;
export const Panel = () => null;
export const PanelResizeHandle = () => null;
export default { PanelGroup, Panel, PanelResizeHandle };
