import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface AuthUser {
  id: number;
  username: string;
  role: string;
  token: string;
}

interface AuthContextType {
  user: AuthUser | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

const SESSION_KEY = "pt_session_token";

// Store token in sessionStorage (not localStorage — avoids the forbidden API ban)
function getStoredToken(): string | null {
  try { return sessionStorage.getItem(SESSION_KEY); } catch { return null; }
}
function setStoredToken(t: string) {
  try { sessionStorage.setItem(SESSION_KEY, t); } catch {}
}
function clearStoredToken() {
  try { sessionStorage.removeItem(SESSION_KEY); } catch {}
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  // On mount: try to restore session from stored token
  useEffect(() => {
    const token = getStoredToken();
    if (!token) { setLoading(false); return; }

    fetch("/api/auth/me", { headers: { "x-session-token": token } })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data?.id) setUser(data);
        else clearStoredToken();
      })
      .catch(() => clearStoredToken())
      .finally(() => setLoading(false));
  }, []);

  async function login(username: string, password: string) {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Login failed");
    setStoredToken(data.token);
    setUser(data);
  }

  async function logout() {
    const token = getStoredToken();
    if (token) {
      fetch("/api/auth/logout", {
        method: "POST",
        headers: { "x-session-token": token },
      }).catch(() => {});
    }
    clearStoredToken();
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
