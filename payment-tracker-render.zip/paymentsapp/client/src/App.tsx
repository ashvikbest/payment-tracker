import { Switch, Route, Router, Redirect } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { AuthProvider, useAuth } from "@/lib/auth";

import Login            from "@/pages/login";
import Register         from "@/pages/register";
import ForgotPw         from "@/pages/forgot-password";
import Dashboard        from "@/pages/dashboard";
import AccountCreation  from "@/pages/account-creation";
import PaymentsForm     from "@/pages/payments-form";
import AccountStatement from "@/pages/account-statement";
import ManagerApprovals from "@/pages/manager-approvals";
import CeoApprovals     from "@/pages/ceo-approvals";
import PurchaseForm     from "@/pages/purchase-form";
import PurchaseStatement from "@/pages/purchase-statement";
import ActivityLog      from "@/pages/activity-log";
import BankUpdates      from "@/pages/bank-updates";
import Reports          from "@/pages/reports";
import NotFound         from "@/pages/not-found";

const PAGE_TITLES: Record<string, string> = {
  "/":                    "Dashboard",
  "/account-creation":    "Account Creation",
  "/payments-form":       "Payment Upload",
  "/account-statement":   "Account Statement",
  "/manager-approvals":   "Manager Approvals",
  "/ceo-approvals":       "CEO Approvals",
  "/purchase-form":       "Purchase Form",
  "/purchase-statement":  "Purchase Statement",
  "/activity-log":        "Activity Log",
  "/bank-updates":        "Bank Updates",
  "/reports":             "Payment Report",
};

function Header() {
  const [location] = useHashLocation();
  const { user } = useAuth();
  const title = PAGE_TITLES[location] ?? "Payment Tracker";
  return (
    <header className="flex items-center justify-between px-6 h-14 border-b bg-card shrink-0">
      <div className="flex items-center gap-3">
        <SidebarTrigger className="-ml-1" />
        <h1 className="text-base font-semibold">{title}</h1>
      </div>
      {user && (
        <div className="text-right hidden sm:block">
          <p className="text-xs font-semibold text-foreground">{user.username}</p>
          <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
        </div>
      )}
    </header>
  );
}

function AuthenticatedLayout() {
  return (
    <SidebarProvider style={{ "--sidebar-width": "240px" } as React.CSSProperties}>
      <div className="flex h-screen w-full overflow-hidden">
        <AppSidebar />
        <div className="flex flex-col flex-1 min-w-0">
          <Header />
          <main className="flex-1 overflow-y-auto bg-background">
            <Switch>
              <Route path="/"                    component={Dashboard} />
              <Route path="/account-creation"    component={AccountCreation} />
              <Route path="/payments-form"       component={PaymentsForm} />
              <Route path="/account-statement"   component={AccountStatement} />
              <Route path="/manager-approvals"   component={ManagerApprovals} />
              <Route path="/ceo-approvals"       component={CeoApprovals} />
              <Route path="/purchase-form"       component={PurchaseForm} />
              <Route path="/purchase-statement"  component={PurchaseStatement} />
              <Route path="/activity-log"        component={ActivityLog} />
              <Route path="/bank-updates"        component={BankUpdates} />
              <Route path="/reports"            component={Reports} />
              <Route component={NotFound} />
            </Switch>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function AppRoutes() {
  const { user } = useAuth();
  const [location] = useHashLocation();

  const publicRoutes = ["/login", "/register", "/forgot-password"];
  const isPublic = publicRoutes.includes(location);

  if (!user) {
    return (
      <Switch>
        <Route path="/login"           component={Login} />
        <Route path="/register"        component={Register} />
        <Route path="/forgot-password" component={ForgotPw} />
        <Route><Redirect to="/login" /></Route>
      </Switch>
    );
  }

  if (isPublic) {
    return <Redirect to="/" />;
  }

  return <AuthenticatedLayout />;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Router hook={useHashLocation}>
            <AppRoutes />
          </Router>
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
