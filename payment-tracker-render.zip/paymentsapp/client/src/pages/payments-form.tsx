import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import type { Payment } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { IndianRupee, Loader2 } from "lucide-react";

const inr = (n: number) => "₹" + n.toLocaleString("en-IN");
const today = () => new Date().toISOString().split("T")[0];

type RowState = { amount: string; date: string; narration: string; submitting: boolean; };

export default function PaymentsForm() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [costFilter, setCostFilter] = useState("all");
  const [rows, setRows] = useState<Record<number, RowState>>({});

  const { data: payments = [], isLoading } = useQuery<Payment[]>({ queryKey: ["/api/payments"] });
  const costCenters = [...new Set(payments.map(p => p.costCenter))];

  const filtered = payments.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchCost = costFilter === "all" || p.costCenter === costFilter;
    return matchSearch && matchCost;
  });

  function getRow(id: number): RowState {
    return rows[id] ?? { amount: "", date: today(), narration: "", submitting: false };
  }
  function updRow(id: number, k: keyof RowState, v: any) {
    setRows(r => ({ ...r, [id]: { ...getRow(id), [k]: v } }));
  }

  const submitMut = useMutation({
    mutationFn: (d: any) => apiRequest("POST", "/api/payment-txns", d),
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries();
      toast({ title: `₹${Number(vars.amount).toLocaleString("en-IN")} submitted for '${vars.paymentName}' successfully.`, duration: 5000 });
      setRows(r => ({ ...r, [vars.paymentId]: { amount: "", date: today(), narration: "", submitting: false } }));
    },
    onError: (e: any, vars: any) => {
      setRows(r => ({ ...r, [vars.paymentId]: { ...getRow(vars.paymentId), submitting: false } }));
      toast({ title: e.message || "Error submitting", variant: "destructive" });
    },
  });

  function handleSubmit(p: Payment) {
    const row = getRow(p.id);
    if (!row.amount || parseFloat(row.amount) <= 0) { toast({ title: "Please enter a valid amount.", variant: "destructive" }); return; }
    if (!row.date) { toast({ title: "Please select a date.", variant: "destructive" }); return; }
    if (!row.narration.trim()) { toast({ title: "Please enter a narration before submitting.", variant: "destructive" }); return; }
    updRow(p.id, "submitting", true);
    submitMut.mutate({ paymentId: p.id, paymentName: p.name, costCenter: p.costCenter, amount: parseFloat(row.amount), date: row.date, narration: row.narration, submittedBy: user?.username ?? "unknown" });
  }

  const overdayBadge = (p: Payment) => {
    const diff = new Date().getDate() - p.dueDay;
    if (diff > 0) return <Badge className="bg-orange-100 text-orange-700 border-orange-200 text-xs">{diff}d overdue</Badge>;
    return <Badge variant="outline" className="text-xs text-muted-foreground">Not Due</Badge>;
  };

  return (
    <div className="p-6 max-w-7xl space-y-5">
      <div>
        <h2 className="text-sm text-muted-foreground">Review and submit individual payment entries</h2>
      </div>
      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <Input placeholder="Search by payment name..." value={search} onChange={e => setSearch(e.target.value)} className="max-w-xs" />
        <Select value={costFilter} onValueChange={setCostFilter}>
          <SelectTrigger className="w-44"><SelectValue placeholder="All Cost Centres" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Cost Centres</SelectItem>
            {costCenters.map(cc => <SelectItem key={cc} value={cc}>{cc}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-card rounded-xl border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/30">
                {["PAYMENT NAME","TOTAL OUTSTANDING","COST CENTRE","OVERDUE","PAYMENT AMOUNT","PAYMENT DATE","NARRATION","ACTION"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? Array.from({ length: 3 }).map((_, i) => (
                <tr key={i} className="border-b">{Array.from({ length: 8 }).map((_, j) => <td key={j} className="px-4 py-4"><Skeleton className="h-4 w-20" /></td>)}</tr>
              )) : filtered.length === 0 ? (
                <tr><td colSpan={8} className="px-4 py-12 text-center text-muted-foreground">No payments found.</td></tr>
              ) : filtered.map(p => {
                const row = getRow(p.id);
                return (
                  <tr key={p.id} className="border-b last:border-0 hover:bg-muted/10" data-testid={`payment-row-${p.id}`}>
                    <td className="px-4 py-3 font-semibold">{p.name}</td>
                    <td className="px-4 py-3 font-bold text-primary">{inr(p.totalOutstanding)}</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">{p.costCenter}</Badge>
                    </td>
                    <td className="px-4 py-3">{overdayBadge(p)}</td>
                    <td className="px-4 py-3">
                      <div className="relative w-32">
                        <IndianRupee className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                        <Input type="number" className="pl-7 h-8 text-sm" placeholder="Amount" value={row.amount}
                          onChange={e => updRow(p.id, "amount", e.target.value)} data-testid={`input-amount-${p.id}`} />
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Input type="date" className="h-8 text-sm w-36" value={row.date}
                        onChange={e => updRow(p.id, "date", e.target.value)} data-testid={`input-date-${p.id}`} />
                    </td>
                    <td className="px-4 py-3">
                      <Input className="h-8 text-sm w-40" placeholder="Narration" value={row.narration}
                        onChange={e => updRow(p.id, "narration", e.target.value)} data-testid={`input-narration-${p.id}`} />
                    </td>
                    <td className="px-4 py-3">
                      <Button size="sm" className="h-8 gap-1.5" onClick={() => handleSubmit(p)} disabled={row.submitting} data-testid={`submit-${p.id}`}>
                        {row.submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <IndianRupee className="w-3.5 h-3.5" />}
                        Submit
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!isLoading && <p className="px-4 py-2 text-xs text-muted-foreground border-t">Showing {filtered.length} of {payments.length} payments</p>}
        </div>
      </div>
    </div>
  );
}
