import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/lib/auth";
import type { Payment, PaymentTxn, BankBalance } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Banknote, Clock, CheckCircle2, XCircle, AlertTriangle,
  TrendingDown, ArrowRight, IndianRupee, FileText, Upload,
  Building2, WalletCards
} from "lucide-react";

const inr = (n: number) => "₹" + n.toLocaleString("en-IN");

function getBankForCostCenter(cc: string) {
  return cc.toLowerCase().includes("andheri") ? "Maaching" : "DSR";
}

function statusBadge(s: string) {
  if (s === "Pending") return <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs">Pending</Badge>;
  if (s === "ManagerApproved") return <Badge className="bg-blue-100 text-blue-700 border-blue-200 text-xs">Mgr Approved</Badge>;
  if (s === "ManagerRejected") return <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">Rejected</Badge>;
  if (s === "Approved") return <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-xs">Approved</Badge>;
  if (s === "CEORejected") return <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">Rejected</Badge>;
  return <Badge variant="outline" className="text-xs">{s}</Badge>;
}

function BankDetailCard({
  bank,
  txns,
  isLoading,
}: {
  bank: BankBalance;
  txns: PaymentTxn[];
  isLoading: boolean;
}) {
  // All pending/mgr-approved txns routed to this bank
  const pendingForBank = txns.filter(
    t =>
      (t.approvalStatus === "Pending" || t.approvalStatus === "ManagerApproved") &&
      getBankForCostCenter(t.costCenter) === bank.bankName
  );
  const pendingTotal = pendingForBank.reduce((s, t) => s + t.amount, 0);
  const projectedBalance = bank.amount - pendingTotal;
  const isLow = projectedBalance < bank.amount * 0.2;
  const isOverdrawn = projectedBalance < 0;
  const pct = Math.min(100, Math.max(0, (projectedBalance / bank.amount) * 100));

  // Group by cost centre
  const byCostCentre: Record<string, { pending: number; mgrApproved: number; total: number }> = {};
  for (const t of pendingForBank) {
    if (!byCostCentre[t.costCenter]) byCostCentre[t.costCenter] = { pending: 0, mgrApproved: 0, total: 0 };
    byCostCentre[t.costCenter].total += t.amount;
    if (t.approvalStatus === "Pending") byCostCentre[t.costCenter].pending += t.amount;
    if (t.approvalStatus === "ManagerApproved") byCostCentre[t.costCenter].mgrApproved += t.amount;
  }

  return (
    <div className={`bg-card border rounded-xl shadow-sm overflow-hidden ${isOverdrawn ? "border-red-300" : isLow ? "border-amber-200" : ""}`}>
      {/* Header */}
      <div className={`px-5 py-4 border-b flex items-center justify-between ${isOverdrawn ? "bg-red-50" : isLow ? "bg-amber-50" : "bg-muted/20"}`}>
        <div className="flex items-center gap-2">
          <Building2 className={`w-4 h-4 ${isOverdrawn ? "text-red-500" : isLow ? "text-amber-500" : "text-primary"}`} />
          <h3 className="text-sm font-semibold">{bank.bankName} Bank</h3>
        </div>
        <Link href="/bank-updates" className="text-xs text-primary hover:underline flex items-center gap-1">
          Update <ArrowRight className="w-3 h-3" />
        </Link>
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* Current balance + bar */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted-foreground">Current Balance</span>
            <span className="text-lg font-bold text-primary">{isLoading ? <Skeleton className="h-6 w-24 inline-block" /> : inr(bank.amount)}</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2 mb-1">
            <div
              className={`h-2 rounded-full transition-all ${isOverdrawn ? "bg-red-500" : isLow ? "bg-amber-400" : "bg-emerald-500"}`}
              style={{ width: `${pct}%` }}
            />
          </div>
          <p className="text-[11px] text-muted-foreground">as of {bank.date}</p>
        </div>

        {/* Pending breakdown */}
        {pendingForBank.length > 0 ? (
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Pending Outflows</p>
            <div className="space-y-1.5">
              {Object.entries(byCostCentre).map(([cc, vals]) => (
                <div key={cc} className="flex items-center justify-between text-xs bg-muted/30 rounded-lg px-3 py-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0 bg-blue-50 text-blue-700 border-blue-200">{cc}</Badge>
                    <div className="flex gap-1.5">
                      {vals.pending > 0 && <span className="text-amber-600 font-medium">{inr(vals.pending)} pending</span>}
                      {vals.mgrApproved > 0 && <span className="text-blue-600 font-medium">{inr(vals.mgrApproved)} mgr apr.</span>}
                    </div>
                  </div>
                  <span className="font-semibold text-foreground">{inr(vals.total)}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 flex items-center justify-between border-t pt-2">
              <span className="text-xs font-semibold">Total Pending</span>
              <span className="text-sm font-bold text-amber-600">{inr(pendingTotal)}</span>
            </div>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground text-center py-2">No pending payments</p>
        )}

        {/* Projected balance */}
        <div className={`rounded-lg px-4 py-3 flex items-center justify-between ${isOverdrawn ? "bg-red-50 border border-red-200" : "bg-emerald-50 border border-emerald-200"}`}>
          <span className={`text-xs font-semibold ${isOverdrawn ? "text-red-700" : "text-emerald-700"}`}>
            {isOverdrawn ? "⚠ Shortfall After Approval" : "Balance After Approval"}
          </span>
          <span className={`text-sm font-bold ${isOverdrawn ? "text-red-700" : "text-emerald-700"}`}>
            {inr(projectedBalance)}
          </span>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();

  const { data: payments = [], isLoading: pLoading } = useQuery<Payment[]>({ queryKey: ["/api/payments"], refetchInterval: 15000 });
  const { data: txns = [], isLoading: tLoading } = useQuery<PaymentTxn[]>({ queryKey: ["/api/payment-txns"], refetchInterval: 15000 });
  const { data: banks = [], isLoading: bLoading } = useQuery<BankBalance[]>({ queryKey: ["/api/bank-balances"], refetchInterval: 15000 });

  const isLoading = pLoading || tLoading || bLoading;

  // KPI stats
  const totalOutstanding = payments.reduce((s, p) => s + p.totalOutstanding, 0);
  const totalBankBalance = banks.reduce((s, b) => s + b.amount, 0);

  const pendingTxns = txns.filter(t => t.approvalStatus === "Pending");
  const mgrApprovedTxns = txns.filter(t => t.approvalStatus === "ManagerApproved");
  const approvedTxns = txns.filter(t => t.approvalStatus === "Approved");
  const rejectedTxns = txns.filter(t => t.approvalStatus === "ManagerRejected" || t.approvalStatus === "CEORejected");

  const pendingTotal = pendingTxns.reduce((s, t) => s + t.amount, 0);
  const mgrApprovedTotal = mgrApprovedTxns.reduce((s, t) => s + t.amount, 0);

  // Overdue payments
  const today = new Date().getDate();
  // Only show as overdue if: due day has passed this month AND there is still outstanding balance
  const overduePayments = payments.filter(p => p.dueDay && today - p.dueDay > 0 && p.totalOutstanding > 0);

  // Role-based pending
  const myPendingTxns = user?.role === "manager"
    ? pendingTxns.slice(0, 5)
    : user?.role === "ceo"
    ? mgrApprovedTxns.slice(0, 5)
    : [];

  const pendingLabel = user?.role === "manager" ? "Pending Your Approval" : "Awaiting CEO Approval";
  const pendingLink = user?.role === "manager" ? "/manager-approvals" : "/ceo-approvals";
  const pendingCount = user?.role === "manager" ? pendingTxns.length : mgrApprovedTxns.length;
  const pendingAmount = user?.role === "manager" ? pendingTotal : mgrApprovedTotal;

  return (
    <div className="p-6 max-w-7xl space-y-6">

      {/* Welcome */}
      <div>
        <h2 className="text-xl font-bold text-foreground">
          Good {new Date().getHours() < 12 ? "morning" : new Date().getHours() < 17 ? "afternoon" : "evening"}, {user?.username} 👋
        </h2>
        <p className="text-sm text-muted-foreground mt-0.5 capitalize">
          {user?.role} · {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
        </p>
      </div>

      {/* Top KPI Cards — 3 cards (no purchases) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">

        {/* Total Outstanding */}
        <div className="bg-card border rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between gap-1 mb-3">
            <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Total Outstanding</span>
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <IndianRupee className="w-4 h-4 text-primary" />
            </div>
          </div>
          {isLoading ? <Skeleton className="h-8 w-28" /> : (
            <p className="text-2xl font-bold text-primary">{inr(totalOutstanding)}</p>
          )}
          <p className="text-xs text-muted-foreground mt-1">{payments.length} payment accounts</p>
        </div>

        {/* Total Bank Balance */}
        <div className="bg-card border rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between gap-1 mb-3">
            <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Total Bank Balance</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0">
              <WalletCards className="w-4 h-4 text-emerald-600" />
            </div>
          </div>
          {bLoading ? <Skeleton className="h-8 w-28" /> : (
            <p className="text-2xl font-bold text-emerald-600">{inr(totalBankBalance)}</p>
          )}
          <p className="text-xs text-muted-foreground mt-1">{banks.length} banks</p>
        </div>

        {/* Pending Approvals */}
        <div className={`border rounded-xl p-5 shadow-sm ${pendingCount > 0 ? "bg-amber-50 border-amber-200" : "bg-card"}`}>
          <div className="flex items-center justify-between gap-1 mb-3">
            <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Pending Approval</span>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${pendingCount > 0 ? "bg-amber-100" : "bg-muted"}`}>
              <Clock className={`w-4 h-4 ${pendingCount > 0 ? "text-amber-600" : "text-muted-foreground"}`} />
            </div>
          </div>
          {tLoading ? <Skeleton className="h-8 w-16" /> : (
            <p className={`text-2xl font-bold ${pendingCount > 0 ? "text-amber-600" : "text-foreground"}`}>
              {user?.role === "manager" ? pendingTxns.length : user?.role === "ceo" ? mgrApprovedTxns.length : pendingTxns.length}
            </p>
          )}
          <p className="text-xs text-muted-foreground mt-1">
            {user?.role === "manager" ? "awaiting your action" : user?.role === "ceo" ? "manager approved" : "transactions pending"}
          </p>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Left col: Bank cards + Overdue + Quick Actions */}
        <div className="space-y-5">

          {/* Bank-wise Detail Cards — one per bank */}
          {bLoading || tLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 2 }).map((_, i) => (
                <div key={i} className="bg-card border rounded-xl p-5 shadow-sm">
                  <Skeleton className="h-4 w-32 mb-4" />
                  <Skeleton className="h-8 w-full mb-2" />
                  <Skeleton className="h-2 w-full mb-4" />
                  <Skeleton className="h-16 w-full" />
                </div>
              ))}
            </div>
          ) : banks.length === 0 ? (
            <div className="bg-card border rounded-xl p-6 shadow-sm text-center">
              <Banknote className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No banks configured yet.</p>
              <Link href="/bank-updates" className="text-xs text-primary hover:underline mt-1 inline-block">Add bank →</Link>
            </div>
          ) : banks.map(b => (
            <BankDetailCard key={b.id} bank={b} txns={txns} isLoading={isLoading} />
          ))}

          {/* Overdue Payments */}
          {overduePayments.length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-xl shadow-sm overflow-hidden">
              <div className="px-5 py-4 border-b border-red-200 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-500" />
                <h3 className="text-sm font-semibold text-red-700">Overdue Payments</h3>
                <Badge className="bg-red-100 text-red-700 border-red-200 ml-auto text-xs">{overduePayments.length}</Badge>
              </div>
              <div className="divide-y divide-red-100">
                {overduePayments.map(p => {
                  const daysOver = new Date().getDate() - p.dueDay!;
                  return (
                    <div key={p.id} className="px-5 py-3 flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-red-800">{p.name}</p>
                        <p className="text-xs text-red-500">{daysOver}d overdue · due {p.dueDay}</p>
                      </div>
                      <p className="text-sm font-bold text-red-700">{inr(p.totalOutstanding)}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div className="bg-card border rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b bg-muted/20">
              <h3 className="text-sm font-semibold">Quick Actions</h3>
            </div>
            <div className="p-3 grid grid-cols-2 gap-2">
              {[
                { label: "Account Creation", icon: FileText, href: "/account-creation" },
                { label: "Payment Upload", icon: Upload, href: "/payments-form" },
                { label: "Account Statement", icon: TrendingDown, href: "/account-statement" },
                ...(user?.role === "manager" ? [{ label: "Manager Approvals", icon: CheckCircle2, href: "/manager-approvals" }] : []),
                ...(user?.role === "ceo" ? [{ label: "CEO Approvals", icon: CheckCircle2, href: "/ceo-approvals" }] : []),
              ].map(({ label, icon: Icon, href }) => (
                <Link
                  key={href}
                  href={href}
                  className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium bg-muted/40 hover:bg-primary/10 hover:text-primary transition-colors"
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  {label}
                </Link>
              ))}
            </div>
          </div>

        </div>

        {/* Right col (2/3): Pending for approval + Payment Status Summary */}
        <div className="lg:col-span-2 space-y-5">

          {/* Pending for approval — manager / ceo */}
          {(user?.role === "manager" || user?.role === "ceo") && (
            <div className="bg-card border rounded-xl shadow-sm overflow-hidden">
              <div className="px-5 py-4 border-b bg-muted/20 flex items-center justify-between gap-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <Clock className="w-4 h-4 text-amber-500" />
                  <h3 className="text-sm font-semibold">{pendingLabel}</h3>
                  {pendingCount > 0 && (
                    <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs">{pendingCount}</Badge>
                  )}
                </div>
                {pendingCount > 0 && (
                  <Link href={pendingLink} className="text-xs text-primary hover:underline flex items-center gap-1 shrink-0">
                    View all <ArrowRight className="w-3 h-3" />
                  </Link>
                )}
              </div>

              {tLoading ? (
                <div className="p-5 space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
              ) : myPendingTxns.length === 0 ? (
                <div className="px-5 py-10 text-center">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">All caught up — no pending approvals.</p>
                </div>
              ) : (
                <>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-muted/10">
                          {["PAYMENT", "COST CENTRE", "AMOUNT", "DATE", "BY", "STATUS"].map(h => (
                            <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {myPendingTxns.map(t => (
                          <tr key={t.id} className="border-b last:border-0 hover:bg-muted/10 transition-colors">
                            <td className="px-4 py-3 font-medium">{t.paymentName}</td>
                            <td className="px-4 py-3">
                              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs">{t.costCenter}</Badge>
                            </td>
                            <td className="px-4 py-3 font-bold text-primary">{inr(t.amount)}</td>
                            <td className="px-4 py-3 text-muted-foreground text-xs">{t.date}</td>
                            <td className="px-4 py-3 text-muted-foreground text-xs">{t.submittedBy}</td>
                            <td className="px-4 py-3">{statusBadge(t.approvalStatus)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="px-5 py-3 border-t bg-muted/10 flex items-center justify-between gap-2 flex-wrap">
                    <p className="text-xs text-muted-foreground">
                      Total pending: <span className="font-bold text-amber-600">{inr(pendingAmount)}</span>
                    </p>
                    <Link href={pendingLink}>
                      <button className="text-xs bg-primary text-white px-3 py-1.5 rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Go to Approvals
                      </button>
                    </Link>
                  </div>
                </>
              )}
            </div>
          )}

          {/* My submitted payments — account role */}
          {user?.role === "account" && pendingTxns.length > 0 && (
            <div className="bg-card border rounded-xl shadow-sm overflow-hidden">
              <div className="px-5 py-4 border-b bg-muted/20 flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-500" />
                <h3 className="text-sm font-semibold">My Submitted Payments</h3>
                <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs">{pendingTxns.length}</Badge>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/10">
                      {["PAYMENT", "AMOUNT", "DATE", "NARRATION", "STATUS"].map(h => (
                        <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {pendingTxns.slice(0, 5).map(t => (
                      <tr key={t.id} className="border-b last:border-0 hover:bg-muted/10 transition-colors">
                        <td className="px-4 py-3 font-medium">{t.paymentName}</td>
                        <td className="px-4 py-3 font-bold text-primary">{inr(t.amount)}</td>
                        <td className="px-4 py-3 text-muted-foreground text-xs">{t.date}</td>
                        <td className="px-4 py-3 text-muted-foreground text-xs max-w-[140px] truncate">{t.narration}</td>
                        <td className="px-4 py-3">{statusBadge(t.approvalStatus)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Payment Status Summary */}
          <div className="bg-card border rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b bg-muted/20 flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Payment Status Summary</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-y sm:divide-y-0">
              {[
                { label: "Pending", count: pendingTxns.length, amount: pendingTotal, color: "text-amber-600", bg: "bg-amber-50" },
                { label: "Mgr Approved", count: mgrApprovedTxns.length, amount: mgrApprovedTotal, color: "text-blue-600", bg: "bg-blue-50" },
                { label: "Approved", count: approvedTxns.length, amount: approvedTxns.reduce((s, t) => s + t.amount, 0), color: "text-emerald-600", bg: "bg-emerald-50" },
                { label: "Rejected", count: rejectedTxns.length, amount: rejectedTxns.reduce((s, t) => s + t.amount, 0), color: "text-red-500", bg: "bg-red-50" },
              ].map(({ label, count, amount, color, bg }) => (
                <div key={label} className={`px-5 py-4 ${bg}/30`}>
                  <p className="text-xs text-muted-foreground font-medium">{label}</p>
                  <p className={`text-xl font-bold mt-1 ${color}`}>{count}</p>
                  <p className={`text-xs font-medium mt-0.5 ${color}`}>{inr(amount)}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Bank summary table — all txns per bank, side by side */}
          <div className="bg-card border rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b bg-muted/20 flex items-center gap-2">
              <Banknote className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Bank-wise Pending Transactions</h3>
            </div>
            {tLoading || bLoading ? (
              <div className="p-5 space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/10">
                      {["PAYMENT", "COST CENTRE", "BANK", "AMOUNT", "STATUS"].map(h => (
                        <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {txns
                      .filter(t => t.approvalStatus === "Pending" || t.approvalStatus === "ManagerApproved")
                      .sort((a, b) => getBankForCostCenter(a.costCenter).localeCompare(getBankForCostCenter(b.costCenter)))
                      .map(t => (
                        <tr key={t.id} className="border-b last:border-0 hover:bg-muted/10 transition-colors">
                          <td className="px-4 py-3 font-medium">{t.paymentName}</td>
                          <td className="px-4 py-3">
                            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs">{t.costCenter}</Badge>
                          </td>
                          <td className="px-4 py-3">
                            <Badge variant="outline" className="text-xs">{getBankForCostCenter(t.costCenter)} Bank</Badge>
                          </td>
                          <td className="px-4 py-3 font-bold text-primary">{inr(t.amount)}</td>
                          <td className="px-4 py-3">{statusBadge(t.approvalStatus)}</td>
                        </tr>
                      ))}
                    {txns.filter(t => t.approvalStatus === "Pending" || t.approvalStatus === "ManagerApproved").length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-4 py-8 text-center text-sm text-muted-foreground">
                          <CheckCircle2 className="w-6 h-6 text-emerald-400 mx-auto mb-1" />
                          No pending transactions
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
