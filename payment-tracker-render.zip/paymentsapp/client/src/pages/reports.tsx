import { useState, useMemo } from "react";  
import { useQuery } from "@tanstack/react-query";
import type { Payment, PaymentTxn, BankBalance } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  FileBarChart2, Download, Filter, X, IndianRupee,
  CheckCircle2, Clock, XCircle, AlertCircle,
} from "lucide-react";

const inr = (n: number) => "₹" + n.toLocaleString("en-IN");

function getBankForCostCenter(cc: string) {
  return cc.toLowerCase().includes("andheri") ? "Maaching" : "DSR";
}

const STATUS_OPTIONS = [
  { value: "all",             label: "All Statuses" },
  { value: "Pending",         label: "Pending" },
  { value: "ManagerApproved", label: "Manager Approved" },
  { value: "ManagerRejected", label: "Manager Rejected" },
  { value: "Approved",        label: "Approved (CEO)" },
  { value: "CEORejected",     label: "CEO Rejected" },
];

function statusBadge(s: string) {
  if (s === "Pending")         return <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs">Pending</Badge>;
  if (s === "ManagerApproved") return <Badge className="bg-blue-100 text-blue-700 border-blue-200 text-xs">Mgr Approved</Badge>;
  if (s === "ManagerRejected") return <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">Mgr Rejected</Badge>;
  if (s === "Approved")        return <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-xs">Approved</Badge>;
  if (s === "CEORejected")     return <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">CEO Rejected</Badge>;
  return <Badge variant="outline" className="text-xs">{s}</Badge>;
}

function statusIcon(s: string) {
  if (s === "Approved")        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />;
  if (s === "Pending")         return <Clock className="w-3.5 h-3.5 text-amber-500" />;
  if (s === "ManagerApproved") return <Clock className="w-3.5 h-3.5 text-blue-500" />;
  return <XCircle className="w-3.5 h-3.5 text-red-400" />;
}

function fmtDate(d: string) {
  try { return new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }); }
  catch { return d; }
}

function fmtTs(ts: string | null | undefined) {
  if (!ts) return "—";
  try { return new Date(ts).toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: true }); }
  catch { return ts; }
}

// ── Build server-side Excel download URL ─────────────────────────────────────
function buildExcelUrl(filters: {
  paymentName: string; fromDate: string; toDate: string;
  costCenter: string; bankName: string; actionType: string;
}) {
  const p = new URLSearchParams();
  if (filters.paymentName && filters.paymentName !== "all") p.set("paymentName", filters.paymentName);
  if (filters.fromDate)  p.set("from", filters.fromDate.slice(0, 10));
  if (filters.toDate)    p.set("to",   filters.toDate.slice(0, 10));
  if (filters.costCenter && filters.costCenter !== "all") p.set("costCenter", filters.costCenter);
  if (filters.bankName   && filters.bankName !== "all")   p.set("bankName",   filters.bankName);
  if (filters.actionType && filters.actionType !== "all") p.set("actionType", filters.actionType);
  const base = typeof window !== "undefined" && (window as any).__API_BASE__ ? (window as any).__API_BASE__ : "";
  return `${base}/api/reports/excel?${p.toString()}`;
}

// ── KPI Card ─────────────────────────────────────────────────────────────────
function KpiCard({ label, count, amount, color, bg, icon }: {
  label: string; count: number; amount: number;
  color: string; bg: string; icon: React.ReactNode;
}) {
  return (
    <div className={`${bg} border rounded-xl p-4 shadow-sm`}>
      <div className="flex items-center justify-between gap-1 mb-2">
        <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">{label}</span>
        <div className="w-7 h-7 rounded-lg bg-white/60 flex items-center justify-center shrink-0">{icon}</div>
      </div>
      <p className={`text-xl font-bold ${color}`}>{count}</p>
      <p className={`text-xs font-medium mt-0.5 ${color}`}>{inr(amount)}</p>
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────
export default function Reports() {
  const [paymentName, setPaymentName] = useState("all");
  const [fromDate,    setFromDate]    = useState("");
  const [toDate,      setToDate]      = useState("");
  const [costCenter,  setCostCenter]  = useState("all");
  const [bankName,    setBankName]    = useState("all");
  const [actionType,  setActionType]  = useState("all");


  const { data: txns    = [], isLoading: tLoading } = useQuery<PaymentTxn[]>({ queryKey: ["/api/payment-txns"] });
  const { data: banks   = [], isLoading: bLoading } = useQuery<BankBalance[]>({ queryKey: ["/api/bank-balances"] });

  const isLoading = tLoading || bLoading;

  const costCenterOptions = useMemo(() => [...new Set(txns.map(t => t.costCenter))].sort(), [txns]);
  const bankOptions       = useMemo(() => [...new Set(banks.map(b => b.bankName))].sort(), [banks]);
  const paymentNameOpts   = useMemo(() => [...new Set(txns.map(t => t.paymentName))].sort(), [txns]);

  // ── Date range fix: normalise both sides to midnight for reliable comparison
  const filtered = useMemo(() => {
    // Normalise a date string to YYYY-MM-DD regardless of input format
    const norm = (d: string) => {
      if (!d) return "";
      // HTML date inputs always give YYYY-MM-DD, but normalise just in case
      const s = d.slice(0, 10);
      return s;
    };
    const from = norm(fromDate);
    const to   = norm(toDate);

    return txns.filter(t => {
      if (paymentName !== "all" && t.paymentName !== paymentName) return false;
      const txDate = norm(t.date);
      if (from && txDate < from) return false;
      if (to   && txDate > to)   return false;
      if (costCenter !== "all" && t.costCenter !== costCenter) return false;
      if (bankName !== "all"   && getBankForCostCenter(t.costCenter) !== bankName) return false;
      if (actionType !== "all" && t.approvalStatus !== actionType) return false;
      return true;
    }).sort((a, b) => b.date.localeCompare(a.date));
  }, [txns, paymentName, fromDate, toDate, costCenter, bankName, actionType]);

  const totalFiltered   = filtered.reduce((s, t) => s + t.amount, 0);
  const approvedRows    = filtered.filter(t => t.approvalStatus === "Approved");
  const pendingRows     = filtered.filter(t => t.approvalStatus === "Pending" || t.approvalStatus === "ManagerApproved");
  const rejectedRows    = filtered.filter(t => t.approvalStatus === "ManagerRejected" || t.approvalStatus === "CEORejected");

  const hasFilters = paymentName !== "all" || fromDate || toDate || costCenter !== "all" || bankName !== "all" || actionType !== "all";

  function clearFilters() {
    setPaymentName("all"); setFromDate(""); setToDate("");
    setCostCenter("all"); setBankName("all"); setActionType("all");
  }

  const excelUrl = buildExcelUrl({ paymentName, fromDate, toDate, costCenter, bankName, actionType });

  return (
    <div className="p-6 max-w-7xl space-y-6">

      {/* Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
            <FileBarChart2 className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Payment Report</h2>
            <p className="text-xs text-muted-foreground">Filter, view and export payment transactions</p>
          </div>
        </div>
        <a
          href={filtered.length > 0 ? excelUrl : undefined}
          download
          className={[
            "inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-colors",
            filtered.length > 0
              ? "bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer"
              : "bg-muted text-muted-foreground pointer-events-none opacity-50"
          ].join(" ")}
        >
          <Download className="w-4 h-4" />
          Export Excel ({filtered.length})
        </a>
      </div>

      {/* Filters */}
      <div className="bg-card border rounded-xl shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b bg-muted/20 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Filters</h3>
            {hasFilters && <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">Active</Badge>}
          </div>
          {hasFilters && (
            <button onClick={clearFilters} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors">
              <X className="w-3.5 h-3.5" /> Clear all
            </button>
          )}
        </div>

        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">

          {/* Payment Name */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Payment Name</Label>
            {isLoading ? <Skeleton className="h-9 w-full" /> : (
              <Select value={paymentName} onValueChange={setPaymentName}>
                <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="All payments" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Payments</SelectItem>
                  {paymentNameOpts.map(n => <SelectItem key={n} value={n}>{n}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
          </div>

          {/* Date From */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Date From</Label>
            <input
              type="date"
              value={fromDate}
              onChange={e => setFromDate(e.target.value)}
              style={{ colorScheme: "light" }}
              className="w-full h-9 rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>

          {/* Date To */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Date To</Label>
            <input
              type="date"
              value={toDate}
              onChange={e => setToDate(e.target.value)}
              style={{ colorScheme: "light" }}
              className="w-full h-9 rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>

          {/* Cost Centre */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Cost Centre</Label>
            {isLoading ? <Skeleton className="h-9 w-full" /> : (
              <Select value={costCenter} onValueChange={setCostCenter}>
                <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="All cost centres" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cost Centres</SelectItem>
                  {costCenterOptions.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
          </div>

          {/* Bank Name */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Bank Name</Label>
            {isLoading ? <Skeleton className="h-9 w-full" /> : (
              <Select value={bankName} onValueChange={setBankName}>
                <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="All banks" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Banks</SelectItem>
                  {bankOptions.map(b => <SelectItem key={b} value={b}>{b} Bank</SelectItem>)}
                </SelectContent>
              </Select>
            )}
          </div>

          {/* Action Type */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Action Type</Label>
            <Select value={actionType} onValueChange={setActionType}>
              <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="All statuses" /></SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

        </div>

        {/* Active filter chips */}
        {hasFilters && (
          <div className="px-5 pb-4 flex flex-wrap gap-2">
            {paymentName !== "all" && (
              <span className="inline-flex items-center gap-1 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-2.5 py-1">
                Payment: {paymentName}
                <button onClick={() => setPaymentName("all")}><X className="w-3 h-3" /></button>
              </span>
            )}
            {fromDate && (
              <span className="inline-flex items-center gap-1 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-2.5 py-1">
                From: {fromDate}
                <button onClick={() => setFromDate("")}><X className="w-3 h-3" /></button>
              </span>
            )}
            {toDate && (
              <span className="inline-flex items-center gap-1 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-2.5 py-1">
                To: {toDate}
                <button onClick={() => setToDate("")}><X className="w-3 h-3" /></button>
              </span>
            )}
            {costCenter !== "all" && (
              <span className="inline-flex items-center gap-1 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-2.5 py-1">
                Centre: {costCenter}
                <button onClick={() => setCostCenter("all")}><X className="w-3 h-3" /></button>
              </span>
            )}
            {bankName !== "all" && (
              <span className="inline-flex items-center gap-1 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-2.5 py-1">
                Bank: {bankName}
                <button onClick={() => setBankName("all")}><X className="w-3 h-3" /></button>
              </span>
            )}
            {actionType !== "all" && (
              <span className="inline-flex items-center gap-1 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-2.5 py-1">
                Status: {STATUS_OPTIONS.find(s => s.value === actionType)?.label}
                <button onClick={() => setActionType("all")}><X className="w-3 h-3" /></button>
              </span>
            )}
          </div>
        )}
      </div>

      {/* Summary KPIs */}
      {!isLoading && filtered.length > 0 && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <KpiCard label="Total Amount"       count={filtered.length}   amount={totalFiltered}
            color="text-primary"     bg="bg-primary/5 border-primary/20"
            icon={<IndianRupee className="w-3.5 h-3.5 text-primary" />} />
          <KpiCard label="Approved"           count={approvedRows.length} amount={approvedRows.reduce((s,t)=>s+t.amount,0)}
            color="text-emerald-600" bg="bg-emerald-50 border-emerald-200"
            icon={<CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />} />
          <KpiCard label="Pending / In Review" count={pendingRows.length} amount={pendingRows.reduce((s,t)=>s+t.amount,0)}
            color="text-amber-600"   bg="bg-amber-50 border-amber-200"
            icon={<Clock className="w-3.5 h-3.5 text-amber-500" />} />
          <KpiCard label="Rejected"           count={rejectedRows.length} amount={rejectedRows.reduce((s,t)=>s+t.amount,0)}
            color="text-red-500"     bg="bg-red-50 border-red-200"
            icon={<AlertCircle className="w-3.5 h-3.5 text-red-400" />} />
        </div>
      )}

      {/* Table */}
      <div className="bg-card border rounded-xl shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b bg-muted/20 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold">Transactions</h3>
            <Badge variant="outline" className="text-xs">{filtered.length} record{filtered.length !== 1 ? "s" : ""}</Badge>
          </div>
          {filtered.length > 0 && (
            <p className="text-xs text-muted-foreground">
              Total: <span className="font-bold text-foreground">{inr(totalFiltered)}</span>
            </p>
          )}
        </div>

        {isLoading ? (
          <div className="p-5 space-y-3">{Array.from({length: 5}).map((_,i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
        ) : filtered.length === 0 ? (
          <div className="px-5 py-16 text-center">
            <FileBarChart2 className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
            <p className="text-sm font-medium text-muted-foreground">No transactions match the selected filters.</p>
            {hasFilters && <button onClick={clearFilters} className="text-xs text-primary hover:underline mt-1">Clear filters to see all</button>}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/10">
                  {["#","Payment Name","Cost Centre","Bank","Amount","Date","Narration","Submitted By","Mgr Reviewed","CEO Reviewed","Status"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((t, i) => (
                  <tr key={t.id} className="border-b last:border-0 hover:bg-muted/10 transition-colors">
                    <td className="px-4 py-3 text-muted-foreground text-xs">{i + 1}</td>
                    <td className="px-4 py-3 font-medium whitespace-nowrap">{t.paymentName}</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs whitespace-nowrap">{t.costCenter}</Badge>
                    </td>
                    <td className="px-4 py-3 text-xs font-medium whitespace-nowrap">{getBankForCostCenter(t.costCenter)} Bank</td>
                    <td className="px-4 py-3 font-bold text-primary whitespace-nowrap">{inr(t.amount)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{fmtDate(t.date)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground max-w-[160px] truncate" title={t.narration}>{t.narration}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{t.submittedBy}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{fmtTs(t.managerReviewedAt)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{fmtTs(t.ceoReviewedAt)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        {statusIcon(t.approvalStatus)}
                        {statusBadge(t.approvalStatus)}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-muted/20 border-t-2">
                  <td colSpan={4} className="px-4 py-3 text-xs font-semibold text-muted-foreground">
                    TOTAL ({filtered.length} transactions)
                  </td>
                  <td className="px-4 py-3 font-bold text-primary text-sm">{inr(totalFiltered)}</td>
                  <td colSpan={6} />
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
