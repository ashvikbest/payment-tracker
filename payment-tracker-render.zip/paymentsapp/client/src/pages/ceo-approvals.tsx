import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import type { PaymentTxn, BankBalance } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle2, XCircle, Search, Banknote, AlertTriangle, Clock, ArrowDown } from "lucide-react";

const inr = (n: number) => "₹" + n.toLocaleString("en-IN");

function nowStamp() {
  return new Date().toLocaleString("en-IN", {
    day: "2-digit", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
    hour12: true,
  });
}

function getBankForCostCenter(costCenter: string): string {
  return costCenter.toLowerCase().includes("andheri") ? "Maaching" : "DSR";
}

function statusBadge(s: string) {
  if (s === "Pending") return <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs">Pending</Badge>;
  if (s === "ManagerApproved") return <Badge className="bg-blue-100 text-blue-700 border-blue-200 text-xs">Manager Approved</Badge>;
  if (s === "ManagerRejected") return <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">Manager Rejected</Badge>;
  if (s === "Approved") return <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-xs">Approved</Badge>;
  if (s === "CEORejected") return <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">CEO Rejected</Badge>;
  return <Badge variant="outline" className="text-xs">{s}</Badge>;
}

export default function CeoApprovals() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [commentTxn, setCommentTxn] = useState<{ txn: PaymentTxn; action: "approve" | "reject" } | null>(null);
  const [comment, setComment] = useState("");
  const [overBudgetWarning, setOverBudgetWarning] = useState<{ bankName: string; balance: number; required: number } | null>(null);
  const [selectionStamp, setSelectionStamp] = useState<string>("");

  const { data: txns = [], isLoading } = useQuery<PaymentTxn[]>({ queryKey: ["/api/payment-txns"] });
  const { data: banks = [] } = useQuery<BankBalance[]>({ queryKey: ["/api/bank-balances"] });

  const managerApproved = txns.filter(t => t.approvalStatus === "ManagerApproved");
  const filtered = managerApproved.filter(t =>
    t.paymentName.toLowerCase().includes(search.toLowerCase()) ||
    t.costCenter.toLowerCase().includes(search.toLowerCase()) ||
    t.submittedBy.toLowerCase().includes(search.toLowerCase())
  );

  // Sum selected amounts per bank
  const selectedTxns = filtered.filter(t => selected.has(t.id));
  const selectedByBank: Record<string, number> = {};
  for (const t of selectedTxns) {
    const bank = getBankForCostCenter(t.costCenter);
    selectedByBank[bank] = (selectedByBank[bank] ?? 0) + t.amount;
  }

  const bankMap = Object.fromEntries(banks.map(b => [b.bankName, b]));

  const overBudgetBanks = banks.filter(b => {
    const used = selectedByBank[b.bankName] ?? 0;
    return used > 0 && used > b.amount;
  });

  useEffect(() => {
    if (selected.size > 0) {
      setSelectionStamp(nowStamp());
    } else {
      setSelectionStamp("");
    }
  }, [selected.size, JSON.stringify(selectedByBank)]);

  useEffect(() => {
    if (overBudgetBanks.length > 0 && selected.size > 0) {
      setOverBudgetWarning({
        bankName: overBudgetBanks[0].bankName,
        balance: overBudgetBanks[0].amount,
        required: selectedByBank[overBudgetBanks[0].bankName],
      });
    } else {
      setOverBudgetWarning(null);
    }
  }, [selected.size, JSON.stringify(selectedByBank)]);

  const actionMut = useMutation({
    mutationFn: ({ id, action, cmt }: { id: number; action: "approve" | "reject"; cmt: string }) =>
      apiRequest("PATCH", `/api/payment-txns/${id}/ceo`, { action, comment: cmt, username: user?.username }),
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries();
      toast({ title: vars.action === "approve" ? "Transaction approved" : "Transaction rejected" });
      setCommentTxn(null);
      setComment("");
      setSelected(new Set());
    },
    onError: (e: any) => toast({ title: e.message || "Error", variant: "destructive" }),
  });

  function toggleSelect(id: number) {
    setSelected(s => {
      const n = new Set(s);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  }

  function bulkApprove() {
    if (overBudgetBanks.length > 0) {
      toast({
        title: "Insufficient bank balance",
        description: `Selected payments (${inr(selectedByBank[overBudgetBanks[0].bankName])}) exceed ${overBudgetBanks[0].bankName} Bank balance (${inr(overBudgetBanks[0].amount)}). Please deselect some payments.`,
        variant: "destructive",
        duration: 6000,
      });
      return;
    }
    selected.forEach(id => actionMut.mutate({ id, action: "approve", cmt: "" }));
  }

  function openAction(txn: PaymentTxn, action: "approve" | "reject") {
    setCommentTxn({ txn, action });
    setComment("");
  }

  function confirmAction() {
    if (!commentTxn) return;
    actionMut.mutate({ id: commentTxn.txn.id, action: commentTxn.action, cmt: comment });
  }

  const allSelected = filtered.length > 0 && filtered.every(t => selected.has(t.id));

  return (
    <div className="p-6 max-w-7xl space-y-5">

      {/* Over-budget warning banner */}
      {overBudgetWarning && (
        <div className="flex items-start gap-3 bg-red-50 border border-red-200 rounded-xl px-5 py-4 text-sm text-red-700">
          <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-red-500" />
          <div>
            <p className="font-semibold">Insufficient balance — {overBudgetWarning.bankName} Bank</p>
            <p className="mt-0.5">
              Selected payments total <span className="font-bold">{inr(overBudgetWarning.required)}</span> but bank balance is only <span className="font-bold">{inr(overBudgetWarning.balance)}</span>.
              Shortfall: <span className="font-bold">{inr(overBudgetWarning.required - overBudgetWarning.balance)}</span>.
            </p>
          </div>
        </div>
      )}

      {/* Bank Balance Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {banks.map(b => {
          const used = selectedByBank[b.bankName] ?? 0;
          const remaining = b.amount - used;
          const isOver = used > 0 && used > b.amount;
          const hasSelection = used > 0;

          return (
            <div
              key={b.id}
              className={`rounded-xl border shadow-sm overflow-hidden transition-all duration-200 ${
                isOver ? "border-red-300" : hasSelection ? "border-amber-300" : "border-border"
              }`}
            >
              <div className={`px-5 py-4 flex items-center gap-3 ${isOver ? "bg-red-50" : hasSelection ? "bg-amber-50" : "bg-card"}`}>
                <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${isOver ? "bg-red-100" : "bg-primary/10"}`}>
                  <Banknote className={`w-4 h-4 ${isOver ? "text-red-500" : "text-primary"}`} />
                </div>
                <p className={`text-xs font-semibold uppercase tracking-wider ${isOver ? "text-red-600" : "text-muted-foreground"}`}>
                  {b.bankName} Bank
                </p>
              </div>

              <div className={`px-5 divide-y ${isOver ? "divide-red-100 bg-red-50/30" : hasSelection ? "divide-amber-100 bg-amber-50/20" : "divide-border bg-card"}`}>
                <div className="py-3 flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground font-medium">Current Balance</p>
                    <p className="text-[11px] text-muted-foreground/70 flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3" /> as of {b.date}
                    </p>
                  </div>
                  <p className={`text-lg font-bold ${hasSelection ? "text-muted-foreground line-through opacity-60" : "text-primary"}`}>
                    {inr(b.amount)}
                  </p>
                </div>

                {hasSelection && (
                  <>
                    <div className="py-3 flex items-center justify-between">
                      <div>
                        <p className={`text-xs font-medium ${isOver ? "text-red-600" : "text-amber-700"}`}>
                          Selected Payments ({selectedTxns.filter(t => getBankForCostCenter(t.costCenter) === b.bankName).length} txn)
                        </p>
                        <p className="text-[11px] text-muted-foreground/70 flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3" /> selected at {selectionStamp}
                        </p>
                      </div>
                      <p className={`text-base font-bold ${isOver ? "text-red-600" : "text-amber-700"}`}>
                        − {inr(used)}
                      </p>
                    </div>

                    <div className={`py-3 flex items-center justify-between rounded-b-xl ${isOver ? "bg-red-100/60" : "bg-emerald-50/60"}`}>
                      <div className="flex items-center gap-2">
                        <ArrowDown className={`w-3.5 h-3.5 ${isOver ? "text-red-500" : "text-emerald-600"}`} />
                        <div>
                          <p className={`text-xs font-semibold ${isOver ? "text-red-700" : "text-emerald-700"}`}>
                            {isOver ? "Shortfall" : "Balance After Approval"}
                          </p>
                          <p className="text-[11px] text-muted-foreground/70 flex items-center gap-1 mt-0.5">
                            <Clock className="w-3 h-3" /> projected at {selectionStamp}
                          </p>
                        </div>
                      </div>
                      <p className={`text-lg font-bold ${isOver ? "text-red-700" : "text-emerald-700"}`}>
                        {isOver ? `−${inr(Math.abs(remaining))}` : inr(remaining)}
                      </p>
                    </div>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Actions bar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search payments..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        {selected.size > 0 && (
          <Button
            size="sm"
            className={`gap-1.5 ${overBudgetBanks.length > 0 ? "bg-red-500 hover:bg-red-600" : "bg-emerald-600 hover:bg-emerald-700"}`}
            onClick={bulkApprove}
            disabled={actionMut.isPending}
            data-testid="button-bulk-approve"
          >
            <CheckCircle2 className="w-4 h-4" />
            {overBudgetBanks.length > 0 ? "Exceeds Balance" : `Approve Selected (${selected.size})`}
          </Button>
        )}
        <span className="text-sm text-muted-foreground ml-auto">{filtered.length} awaiting CEO approval</span>
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/30">
                <th className="px-4 py-3 w-10">
                  <input
                    type="checkbox"
                    checked={allSelected}
                    onChange={e => {
                      if (e.target.checked) setSelected(new Set(filtered.map(t => t.id)));
                      else setSelected(new Set());
                    }}
                    className="w-4 h-4 accent-primary"
                    data-testid="checkbox-select-all"
                  />
                </th>
                {["PAYMENT NAME", "COST CENTRE", "AMOUNT", "BANK", "DATE", "SUBMITTED BY", "NARRATION", "STATUS", "ACTIONS"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? Array.from({ length: 3 }).map((_, i) => (
                <tr key={i} className="border-b">{Array.from({ length: 10 }).map((_, j) => <td key={j} className="px-4 py-4"><Skeleton className="h-4 w-20" /></td>)}</tr>
              )) : filtered.length === 0 ? (
                <tr><td colSpan={10} className="px-4 py-12 text-center text-muted-foreground">No transactions awaiting CEO approval.</td></tr>
              ) : filtered.map(t => {
                const isSelected = selected.has(t.id);
                const bank = getBankForCostCenter(t.costCenter);
                const bankBalance = bankMap[bank]?.amount ?? 0;
                const usedForBank = selectedByBank[bank] ?? 0;
                const wouldExceed = isSelected && usedForBank > bankBalance;

                return (
                  <tr
                    key={t.id}
                    className={`border-b last:border-0 transition-colors ${
                      wouldExceed ? "bg-red-50" : isSelected ? "bg-blue-50/40" : "hover:bg-muted/10"
                    }`}
                    data-testid={`row-txn-${t.id}`}
                  >
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelect(t.id)}
                        className="w-4 h-4 accent-primary"
                        data-testid={`checkbox-txn-${t.id}`}
                      />
                    </td>
                    <td className="px-4 py-3 font-semibold">{t.paymentName}</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">{t.costCenter}</Badge>
                    </td>
                    <td className={`px-4 py-3 font-bold ${wouldExceed ? "text-red-600" : "text-primary"}`}>{inr(t.amount)}</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className={`text-xs ${bank === "Maaching" ? "bg-purple-50 text-purple-700 border-purple-200" : "bg-cyan-50 text-cyan-700 border-cyan-200"}`}>
                        {bank}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{t.date}</td>
                    <td className="px-4 py-3 text-muted-foreground">{t.submittedBy}</td>
                    <td className="px-4 py-3 max-w-[140px] truncate text-muted-foreground">{t.narration}</td>
                    <td className="px-4 py-3">{statusBadge(t.approvalStatus)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => openAction(t, "approve")}
                          className="flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-800 transition-colors"
                          data-testid={`approve-${t.id}`}
                        >
                          <CheckCircle2 className="w-4 h-4" /> Approve
                        </button>
                        <button
                          onClick={() => openAction(t, "reject")}
                          className="flex items-center gap-1 text-xs font-medium text-red-500 hover:text-red-700 transition-colors"
                          data-testid={`reject-${t.id}`}
                        >
                          <XCircle className="w-4 h-4" /> Reject
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!isLoading && <p className="px-4 py-2 text-xs text-muted-foreground border-t">Showing {filtered.length} of {managerApproved.length} manager-approved transactions</p>}
        </div>
      </div>

      {/* Approve/Reject Dialog */}
      <Dialog open={!!commentTxn} onOpenChange={o => { if (!o) { setCommentTxn(null); setComment(""); } }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {commentTxn?.action === "approve" ? "Approve Transaction" : "Reject Transaction"}
            </DialogTitle>
          </DialogHeader>
          {commentTxn && (
            <div className="space-y-4">
              <div className="bg-muted/30 rounded-lg p-4 space-y-1 text-sm">
                <p><span className="text-muted-foreground">Payment:</span> <span className="font-semibold">{commentTxn.txn.paymentName}</span></p>
                <p><span className="text-muted-foreground">Amount:</span> <span className="font-bold text-primary">{inr(commentTxn.txn.amount)}</span></p>
                <p><span className="text-muted-foreground">Bank:</span> {getBankForCostCenter(commentTxn.txn.costCenter)} Bank</p>
                <p><span className="text-muted-foreground">Submitted by:</span> {commentTxn.txn.submittedBy}</p>
                <p><span className="text-muted-foreground">Narration:</span> {commentTxn.txn.narration}</p>
                {commentTxn.txn.approvalComment && (
                  <p><span className="text-muted-foreground">Manager comment:</span> {commentTxn.txn.approvalComment}</p>
                )}
              </div>
              <div className="space-y-1.5">
                <Label>Comment (optional)</Label>
                <Textarea
                  placeholder="Add a comment..."
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  rows={3}
                  data-testid="input-comment"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => { setCommentTxn(null); setComment(""); }}>Cancel</Button>
            <Button
              onClick={confirmAction}
              disabled={actionMut.isPending}
              className={commentTxn?.action === "approve" ? "bg-emerald-600 hover:bg-emerald-700" : "bg-red-500 hover:bg-red-600"}
              data-testid="button-confirm-action"
            >
              {commentTxn?.action === "approve" ? "Approve" : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
