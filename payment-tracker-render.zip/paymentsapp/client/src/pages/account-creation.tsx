import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import type { Payment } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Pencil, Trash2, TrendingUp, IndianRupee } from "lucide-react";

const inr = (n: number) => "₹" + n.toLocaleString("en-IN");

type FormData = { name: string; totalOutstanding: string; costCenter: string; actionPoint: string; dueDay: string; amount: string; narration: string; };
const emptyForm = (): FormData => ({ name: "", totalOutstanding: "", costCenter: "", actionPoint: "", dueDay: "", amount: "", narration: "" });

export default function AccountCreation() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Payment | null>(null);
  const [form, setForm] = useState<FormData>(emptyForm());
  const [search, setSearch] = useState("");

  const { data: payments = [], isLoading } = useQuery<Payment[]>({ queryKey: ["/api/payments"] });
  const { data: costCenters = [] } = useQuery<string[]>({ queryKey: ["/api/dropdown/costCenter"] });
  const { data: actionPoints = [] } = useQuery<string[]>({ queryKey: ["/api/dropdown/actionPoint"] });

  const totalOutstanding = payments.reduce((s, p) => s + p.totalOutstanding, 0);
  const filtered = payments.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.costCenter.toLowerCase().includes(search.toLowerCase()));

  const createMut = useMutation({
    mutationFn: (d: any) => apiRequest("POST", "/api/payments", { ...d, username: user?.username }),
    onSuccess: () => { queryClient.invalidateQueries(); toast({ title: "Payment created" }); setOpen(false); setForm(emptyForm()); },
    onError: (e: any) => toast({ title: e.message || "Error", variant: "destructive" }),
  });
  const updateMut = useMutation({
    mutationFn: ({ id, d }: any) => apiRequest("PATCH", `/api/payments/${id}`, { ...d, username: user?.username }),
    onSuccess: () => { queryClient.invalidateQueries(); toast({ title: "Payment updated" }); setOpen(false); setEditing(null); },
    onError: (e: any) => toast({ title: e.message || "Error", variant: "destructive" }),
  });
  const deleteMut = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/payments/${id}?username=${user?.username}`),
    onSuccess: () => { queryClient.invalidateQueries(); toast({ title: "Payment deleted", variant: "destructive" }); },
  });

  function openCreate() { setEditing(null); setForm(emptyForm()); setOpen(true); }
  function openEdit(p: Payment) {
    setEditing(p);
    setForm({ name: p.name, totalOutstanding: String(p.totalOutstanding), costCenter: p.costCenter, actionPoint: p.actionPoint, dueDay: String(p.dueDay), amount: String(p.amount), narration: p.narration ?? "" });
    setOpen(true);
  }
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const d = { ...form, totalOutstanding: parseFloat(form.totalOutstanding) || 0, amount: parseFloat(form.amount) || 0, dueDay: parseInt(form.dueDay) || 1 };
    if (editing) updateMut.mutate({ id: editing.id, d });
    else createMut.mutate(d);
  }

  const upd = (k: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement>) => setForm(f => ({ ...f, [k]: e.target.value }));

  const overdueTag = (p: Payment) => {
    const today = new Date().getDate();
    const diff = today - p.dueDay;
    if (diff > 0) return <Badge className="bg-orange-100 text-orange-700 border-orange-200 gap-1 text-xs">{diff}d overdue</Badge>;
    return <Badge variant="secondary" className="text-xs">Not Due</Badge>;
  };

  return (
    <div className="p-6 max-w-7xl space-y-5">
      {/* Summary Card */}
      <div className="bg-card rounded-xl border p-6 flex items-start justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">Monthly</Badge>
          </div>
          {isLoading ? <Skeleton className="h-10 w-40 mb-1" /> : (
            <p className="text-4xl font-bold text-primary tracking-tight" data-testid="text-total">{inr(totalOutstanding)}</p>
          )}
          <p className="text-sm text-muted-foreground mt-1">Total Outstanding</p>
        </div>
        <Button onClick={openCreate} className="gap-1.5 shrink-0" data-testid="button-add-payment">
          <Plus className="w-4 h-4" /> Add New Payment
        </Button>
      </div>

      {/* Search */}
      <div className="flex gap-3">
        <Input placeholder="Search payments..." value={search} onChange={e => setSearch(e.target.value)} className="max-w-xs" />
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/30">
                {["PAYMENT NAME","ACTION POINT","COST CENTER","TOTAL OUTSTANDING","AMOUNT IN ₹","NARRATION","DUE DAY","STATUS","ACTIONS"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? Array.from({ length: 3 }).map((_, i) => (
                <tr key={i} className="border-b">{Array.from({ length: 9 }).map((_, j) => <td key={j} className="px-4 py-4"><Skeleton className="h-4 w-20" /></td>)}</tr>
              )) : filtered.length === 0 ? (
                <tr><td colSpan={9} className="px-4 py-12 text-center text-muted-foreground">No payments found.</td></tr>
              ) : filtered.map(p => (
                <tr key={p.id} className="border-b last:border-0 hover:bg-muted/20 transition-colors" data-testid={`row-${p.id}`}>
                  <td className="px-4 py-4 font-semibold">{p.name}</td>
                  <td className="px-4 py-4 text-muted-foreground">{p.actionPoint}</td>
                  <td className="px-4 py-4">
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">{p.costCenter}</Badge>
                  </td>
                  <td className="px-4 py-4 font-bold text-primary">{inr(p.totalOutstanding)}</td>
                  <td className="px-4 py-4 text-muted-foreground">{inr(p.amount)}</td>
                  <td className="px-4 py-4 text-muted-foreground max-w-[160px] truncate">{p.narration || "—"}</td>
                  <td className="px-4 py-4 text-muted-foreground">{p.dueDay}th</td>
                  <td className="px-4 py-4">{overdueTag(p)}</td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2">
                      <button onClick={() => openEdit(p)} className="text-muted-foreground hover:text-primary transition-colors" data-testid={`edit-${p.id}`}><Pencil className="w-4 h-4" /></button>
                      <button onClick={() => deleteMut.mutate(p.id)} className="text-muted-foreground hover:text-destructive transition-colors" data-testid={`delete-${p.id}`}><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!isLoading && <p className="px-4 py-2 text-xs text-muted-foreground border-t">Showing {filtered.length} of {payments.length} payments</p>}
        </div>
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Payment" : "Add New Payment"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2 space-y-1.5">
                <Label>Payment Name *</Label>
                <Input placeholder="e.g. Salesforce License" value={form.name} onChange={upd("name")} required data-testid="input-name" />
              </div>
              <div className="space-y-1.5">
                <Label>Action Point *</Label>
                <div className="flex gap-2">
                  <Select value={form.actionPoint} onValueChange={v => setForm(f => ({ ...f, actionPoint: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select or add..." /></SelectTrigger>
                    <SelectContent>
                      {actionPoints.map(ap => <SelectItem key={ap} value={ap}>{ap}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <Input placeholder="Or type new..." value={form.actionPoint} onChange={upd("actionPoint")} className="text-xs h-8" />
              </div>
              <div className="space-y-1.5">
                <Label>Cost Center *</Label>
                <Select value={form.costCenter} onValueChange={v => setForm(f => ({ ...f, costCenter: v }))}>
                  <SelectTrigger><SelectValue placeholder="Select or add..." /></SelectTrigger>
                  <SelectContent>
                    {costCenters.map(cc => <SelectItem key={cc} value={cc}>{cc}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Input placeholder="Or type new..." value={form.costCenter} onChange={upd("costCenter")} className="text-xs h-8" />
              </div>
              <div className="space-y-1.5">
                <Label>Total Outstanding (₹) *</Label>
                <div className="relative">
                  <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <Input type="number" className="pl-8" value={form.totalOutstanding} onChange={upd("totalOutstanding")} required />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Amount (₹) *</Label>
                <div className="relative">
                  <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <Input type="number" className="pl-8" value={form.amount} onChange={upd("amount")} required />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Due Day *</Label>
                <Input type="number" min={1} max={31} placeholder="e.g. 10" value={form.dueDay} onChange={upd("dueDay")} required />
              </div>
              <div className="space-y-1.5">
                <Label>Narration</Label>
                <Input placeholder="Optional note" value={form.narration} onChange={upd("narration")} />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={createMut.isPending || updateMut.isPending}>
                {editing ? "Save Changes" : "Create Payment"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
