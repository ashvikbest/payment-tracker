import { useQuery } from "@tanstack/react-query";
import type { Purchase, Payment } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, TrendingDown, Layers } from "lucide-react";

const inr = (n: number) => "₹" + n.toLocaleString("en-IN");

export default function PurchaseStatement() {
  const { data: purchases = [], isLoading } = useQuery<Purchase[]>({ queryKey: ["/api/purchases"] });
  const { data: payments = [] } = useQuery<Payment[]>({ queryKey: ["/api/payments"] });

  const paymentMap = Object.fromEntries(payments.map(p => [p.id, p]));

  // Total spend
  const totalSpent = purchases.reduce((s, p) => s + p.amount, 0);

  // Group by purchaseName
  const grouped: Record<string, Purchase[]> = {};
  for (const p of purchases) {
    if (!grouped[p.purchaseName]) grouped[p.purchaseName] = [];
    grouped[p.purchaseName].push(p);
  }

  const categories = Object.entries(grouped).map(([name, items]) => ({
    name,
    total: items.reduce((s, i) => s + i.amount, 0),
    count: items.length,
    items,
  })).sort((a, b) => b.total - a.total);

  return (
    <div className="p-6 max-w-7xl space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-card rounded-xl border shadow-sm p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <TrendingDown className="w-4 h-4 text-primary" />
            </div>
            <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Total Spent</span>
          </div>
          {isLoading ? <Skeleton className="h-8 w-32" /> : (
            <p className="text-2xl font-bold text-primary" data-testid="text-total-spent">{inr(totalSpent)}</p>
          )}
        </div>
        <div className="bg-card rounded-xl border shadow-sm p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
              <ShoppingCart className="w-4 h-4 text-blue-600" />
            </div>
            <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Total Entries</span>
          </div>
          {isLoading ? <Skeleton className="h-8 w-16" /> : (
            <p className="text-2xl font-bold" data-testid="text-total-entries">{purchases.length}</p>
          )}
        </div>
        <div className="bg-card rounded-xl border shadow-sm p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center">
              <Layers className="w-4 h-4 text-purple-600" />
            </div>
            <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Categories</span>
          </div>
          {isLoading ? <Skeleton className="h-8 w-16" /> : (
            <p className="text-2xl font-bold" data-testid="text-categories">{categories.length}</p>
          )}
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-32 w-full rounded-xl" />)}
        </div>
      ) : categories.length === 0 ? (
        <div className="bg-card rounded-xl border shadow-sm p-12 text-center">
          <ShoppingCart className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No purchases recorded yet.</p>
        </div>
      ) : (
        <div className="space-y-5">
          {/* Category Summary */}
          <div className="bg-card rounded-xl border shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b bg-muted/20">
              <h3 className="text-sm font-semibold">Purchase Categories Summary</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/10">
                    {["PURCHASE NAME", "ENTRIES", "TOTAL SPENT", "% OF TOTAL"].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {categories.map(cat => (
                    <tr key={cat.name} className="border-b last:border-0 hover:bg-muted/10">
                      <td className="px-4 py-3 font-semibold">{cat.name}</td>
                      <td className="px-4 py-3 text-muted-foreground">{cat.count}</td>
                      <td className="px-4 py-3 font-bold text-primary">{inr(cat.total)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-muted rounded-full h-1.5 max-w-[80px]">
                            <div
                              className="bg-primary h-1.5 rounded-full"
                              style={{ width: `${Math.round((cat.total / totalSpent) * 100)}%` }}
                            />
                          </div>
                          <span className="text-muted-foreground text-xs">
                            {totalSpent > 0 ? Math.round((cat.total / totalSpent) * 100) : 0}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Per-category detail cards */}
          {categories.map(cat => (
            <div key={cat.name} className="bg-card rounded-xl border shadow-sm overflow-hidden">
              <div className="px-5 py-4 border-b bg-muted/20 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-4 h-4 text-primary" />
                  <h3 className="text-sm font-semibold">{cat.name}</h3>
                  <Badge variant="secondary" className="text-xs">{cat.count} entries</Badge>
                </div>
                <span className="text-sm font-bold text-primary">{inr(cat.total)}</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/10">
                      {["DATE", "PAYMENT ACCOUNT", "COST CENTRE", "AMOUNT", "NARRATION", "SUBMITTED BY"].map(h => (
                        <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {cat.items.map(item => {
                      const pmt = paymentMap[item.paymentId];
                      return (
                        <tr key={item.id} className="border-b last:border-0 hover:bg-muted/10" data-testid={`purchase-${item.id}`}>
                          <td className="px-4 py-2.5 text-muted-foreground">{item.date}</td>
                          <td className="px-4 py-2.5 font-medium">{pmt?.name ?? `Account #${item.paymentId}`}</td>
                          <td className="px-4 py-2.5">
                            {pmt && <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs">{pmt.costCenter}</Badge>}
                          </td>
                          <td className="px-4 py-2.5 font-bold text-primary">{inr(item.amount)}</td>
                          <td className="px-4 py-2.5 text-muted-foreground max-w-[200px] truncate">{item.narration}</td>
                          <td className="px-4 py-2.5 text-muted-foreground">{item.submittedBy}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
