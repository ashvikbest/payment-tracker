import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import type { Payment } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { IndianRupee, Loader2, Save } from "lucide-react";

const inr = (n: number) => "₹" + n.toLocaleString("en-IN");
const todayStr = () => new Date().toISOString().split("T")[0];

type RowState = {
  paymentId: string;
  purchaseName: string;
  amount: string;
  date: string;
  narration: string;
  saving: boolean;
  saved: boolean;
};

const NUM_ROWS = 5;

function emptyRow(): RowState {
  return { paymentId: "", purchaseName: "", amount: "", date: todayStr(), narration: "", saving: false, saved: false };
}

export default function PurchaseForm() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [rows, setRows] = useState<RowState[]>(Array.from({ length: NUM_ROWS }, emptyRow));

  const { data: payments = [], isLoading } = useQuery<Payment[]>({ queryKey: ["/api/payments"] });

  function updRow(i: number, k: keyof RowState, v: any) {
    setRows(r => r.map((row, idx) => idx === i ? { ...row, [k]: v } : row));
  }

  const saveMut = useMutation({
    mutationFn: (d: any) => apiRequest("POST", "/api/purchases", d),
    onSuccess: (_, vars: any) => {
      const i = vars._rowIndex;
      setRows(r => r.map((row, idx) => idx === i ? { ...emptyRow(), saved: true } : row));
      toast({ title: `Purchase saved: ₹${Number(vars.amount).toLocaleString("en-IN")} for ${vars.purchaseName}` });
      queryClient.invalidateQueries();
    },
    onError: (e: any, vars: any) => {
      const i = vars._rowIndex;
      setRows(r => r.map((row, idx) => idx === i ? { ...row, saving: false } : row));
      toast({ title: e.message || "Error saving purchase", variant: "destructive" });
    },
  });

  function handleSave(i: number) {
    const row = rows[i];
    if (!row.paymentId) { toast({ title: "Please select a payment account.", variant: "destructive" }); return; }
    if (!row.purchaseName.trim()) { toast({ title: "Please enter a purchase name.", variant: "destructive" }); return; }
    if (!row.amount || parseFloat(row.amount) <= 0) { toast({ title: "Please enter a valid amount.", variant: "destructive" }); return; }
    if (!row.date) { toast({ title: "Please select a date.", variant: "destructive" }); return; }
    if (!row.narration.trim()) { toast({ title: "Please enter a narration.", variant: "destructive" }); return; }

    updRow(i, "saving", true);
    const payment = payments.find(p => String(p.id) === row.paymentId);
    saveMut.mutate({
      _rowIndex: i,
      paymentId: parseInt(row.paymentId),
      purchaseName: row.purchaseName.trim(),
      amount: parseFloat(row.amount),
      date: row.date,
      narration: row.narration.trim(),
      submittedBy: user?.username ?? "unknown",
    });
  }

  return (
    <div className="p-6 max-w-7xl space-y-5">
      <div>
        <p className="text-sm text-muted-foreground">Fill in up to {NUM_ROWS} purchase entries. Save each row individually.</p>
      </div>

      <div className="bg-card rounded-xl border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/30">
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide">#</th>
                {["PAYMENT ACCOUNT", "PURCHASE NAME", "AMOUNT (₹)", "DATE", "NARRATION", "ACTION"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr
                  key={i}
                  className={`border-b last:border-0 transition-colors ${row.saved ? "bg-emerald-50/50" : "hover:bg-muted/10"}`}
                  data-testid={`purchase-row-${i}`}
                >
                  <td className="px-4 py-3 text-muted-foreground font-medium">{i + 1}</td>
                  <td className="px-4 py-3">
                    {isLoading ? <Skeleton className="h-8 w-40" /> : (
                      <Select
                        value={row.paymentId}
                        onValueChange={v => updRow(i, "paymentId", v)}
                        disabled={row.saved}
                      >
                        <SelectTrigger className="w-44 h-8 text-sm" data-testid={`select-payment-${i}`}>
                          <SelectValue placeholder="Select account..." />
                        </SelectTrigger>
                        <SelectContent>
                          {payments.map(p => (
                            <SelectItem key={p.id} value={String(p.id)}>
                              {p.name} ({p.costCenter})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <Input
                      className="h-8 text-sm w-40"
                      placeholder="Purchase name"
                      value={row.purchaseName}
                      onChange={e => updRow(i, "purchaseName", e.target.value)}
                      disabled={row.saved}
                      data-testid={`input-purchase-name-${i}`}
                    />
                  </td>
                  <td className="px-4 py-3">
                    <div className="relative w-32">
                      <IndianRupee className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input
                        type="number"
                        className="pl-7 h-8 text-sm"
                        placeholder="Amount"
                        value={row.amount}
                        onChange={e => updRow(i, "amount", e.target.value)}
                        disabled={row.saved}
                        data-testid={`input-amount-${i}`}
                      />
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <Input
                      type="date"
                      className="h-8 text-sm w-36"
                      value={row.date}
                      onChange={e => updRow(i, "date", e.target.value)}
                      disabled={row.saved}
                      data-testid={`input-date-${i}`}
                    />
                  </td>
                  <td className="px-4 py-3">
                    <Input
                      className="h-8 text-sm w-44"
                      placeholder="Narration"
                      value={row.narration}
                      onChange={e => updRow(i, "narration", e.target.value)}
                      disabled={row.saved}
                      data-testid={`input-narration-${i}`}
                    />
                  </td>
                  <td className="px-4 py-3">
                    {row.saved ? (
                      <span className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                        <Save className="w-3.5 h-3.5" /> Saved
                      </span>
                    ) : (
                      <Button
                        size="sm"
                        className="h-8 gap-1.5"
                        onClick={() => handleSave(i)}
                        disabled={row.saving}
                        data-testid={`save-row-${i}`}
                      >
                        {row.saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                        Save
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex justify-end">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setRows(Array.from({ length: NUM_ROWS }, emptyRow))}
          data-testid="button-clear-all"
        >
          Clear All
        </Button>
      </div>
    </div>
  );
}
