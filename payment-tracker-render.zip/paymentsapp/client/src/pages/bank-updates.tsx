import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import type { BankBalance } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, Banknote, RefreshCw, Calendar } from "lucide-react";

const inr = (n: number) => "₹" + n.toLocaleString("en-IN");
const todayStr = () => new Date().toISOString().split("T")[0];

type BankForm = { amount: string; date: string };

export default function BankUpdates() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [forms, setForms] = useState<Record<string, BankForm>>({});

  const { data: banks = [], isLoading } = useQuery<BankBalance[]>({ queryKey: ["/api/bank-balances"] });

  function getForm(bankName: string): BankForm {
    return forms[bankName] ?? { amount: "", date: todayStr() };
  }
  function updForm(bankName: string, k: keyof BankForm, v: string) {
    setForms(f => ({ ...f, [bankName]: { ...getForm(bankName), [k]: v } }));
  }

  const saveMut = useMutation({
    mutationFn: (d: any) => apiRequest("POST", "/api/bank-balances", d),
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries();
      toast({ title: `${vars.bankName} balance updated to ${inr(vars.amount)}` });
      setForms(f => {
        const n = { ...f };
        delete n[vars.bankName];
        return n;
      });
    },
    onError: (e: any) => toast({ title: e.message || "Error updating balance", variant: "destructive" }),
  });

  function handleSave(bankName: string) {
    const form = getForm(bankName);
    const amt = parseFloat(form.amount);
    if (!form.amount || isNaN(amt) || amt < 0) {
      toast({ title: "Please enter a valid amount.", variant: "destructive" });
      return;
    }
    if (!form.date) {
      toast({ title: "Please select a date.", variant: "destructive" });
      return;
    }
    saveMut.mutate({ bankName, amount: amt, date: form.date, updatedBy: user?.username ?? "system" });
  }

  // Known banks — show DSR first, Maaching second
  const BANK_ORDER = ["DSR", "Maaching"];
  const sortedBanks = [...banks].sort((a, b) => {
    const ai = BANK_ORDER.indexOf(a.bankName);
    const bi = BANK_ORDER.indexOf(b.bankName);
    return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
  });

  return (
    <div className="p-6 max-w-3xl space-y-5">
      <div>
        <p className="text-sm text-muted-foreground">Update the current bank balance. This replaces the existing balance.</p>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-48 w-full rounded-xl" />
          <Skeleton className="h-48 w-full rounded-xl" />
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5">
          {sortedBanks.map(bank => {
            const form = getForm(bank.bankName);
            return (
              <div key={bank.bankName} className="bg-card rounded-xl border shadow-sm overflow-hidden" data-testid={`bank-card-${bank.bankName}`}>
                {/* Header */}
                <div className="px-6 py-5 border-b bg-muted/20 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Banknote className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-base">{bank.bankName} Bank</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <p className="text-sm text-muted-foreground">Current balance:</p>
                      <p className="text-sm font-bold text-primary" data-testid={`balance-${bank.bankName}`}>{inr(bank.amount)}</p>
                    </div>
                  </div>
                </div>

                {/* Last updated */}
                <div className="px-6 py-3 border-b bg-muted/5 flex flex-wrap gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    As of {bank.date}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <RefreshCw className="w-3.5 h-3.5" />
                    Updated by {bank.updatedBy || "system"}
                  </span>
                </div>

                {/* Form */}
                <div className="px-6 py-5 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label>New Balance (₹)</Label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">₹</span>
                        <Input
                          type="number"
                          className="pl-7"
                          placeholder="Enter amount"
                          value={form.amount}
                          onChange={e => updForm(bank.bankName, "amount", e.target.value)}
                          data-testid={`input-amount-${bank.bankName}`}
                        />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label>As of Date</Label>
                      <Input
                        type="date"
                        value={form.date}
                        onChange={e => updForm(bank.bankName, "date", e.target.value)}
                        data-testid={`input-date-${bank.bankName}`}
                      />
                    </div>
                  </div>
                  <Button
                    onClick={() => handleSave(bank.bankName)}
                    disabled={saveMut.isPending}
                    className="gap-2"
                    data-testid={`save-${bank.bankName}`}
                  >
                    {saveMut.isPending
                      ? <Loader2 className="w-4 h-4 animate-spin" />
                      : <RefreshCw className="w-4 h-4" />
                    }
                    Update Balance
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
