import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Activity } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Activity as ActivityIcon, CheckCircle2, XCircle } from "lucide-react";

function actionBadge(action: string) {
  const map: Record<string, string> = {
    Login: "bg-blue-100 text-blue-700 border-blue-200",
    Logout: "bg-slate-100 text-slate-600 border-slate-200",
    Register: "bg-purple-100 text-purple-700 border-purple-200",
    "Reset Password": "bg-yellow-100 text-yellow-700 border-yellow-200",
    "Create Payment": "bg-emerald-100 text-emerald-700 border-emerald-200",
    "Update Payment": "bg-teal-100 text-teal-700 border-teal-200",
    "Delete Payment": "bg-red-100 text-red-700 border-red-200",
    "Submit Payment": "bg-indigo-100 text-indigo-700 border-indigo-200",
    "Manager Approved": "bg-emerald-100 text-emerald-700 border-emerald-200",
    "Manager Rejected": "bg-red-100 text-red-700 border-red-200",
    "CEO Approved": "bg-emerald-100 text-emerald-700 border-emerald-200",
    "CEO Rejected": "bg-red-100 text-red-700 border-red-200",
    "Submit Purchase": "bg-orange-100 text-orange-700 border-orange-200",
    "Update Bank Balance": "bg-cyan-100 text-cyan-700 border-cyan-200",
  };
  const cls = map[action] ?? "bg-slate-100 text-slate-600 border-slate-200";
  return <Badge className={`${cls} text-xs font-medium whitespace-nowrap`}>{action}</Badge>;
}

function fmt(ts: string) {
  try {
    return new Date(ts).toLocaleString("en-IN", {
      day: "2-digit", month: "short", year: "numeric",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
      hour12: true,
    });
  } catch {
    return ts;
  }
}

export default function ActivityLog() {
  const [search, setSearch] = useState("");
  const [actionFilter, setActionFilter] = useState("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const { data: activities = [], isLoading } = useQuery<Activity[]>({ queryKey: ["/api/activity"] });

  // Get unique action types
  const actionTypes = [...new Set(activities.map(a => a.action))].sort();

  const filtered = activities.filter(a => {
    const matchSearch = !search ||
      a.username.toLowerCase().includes(search.toLowerCase()) ||
      (a.details ?? "").toLowerCase().includes(search.toLowerCase()) ||
      (a.ipAddress ?? "").toLowerCase().includes(search.toLowerCase());

    const matchAction = actionFilter === "all" || a.action === actionFilter;

    const aDate = a.timestamp.split("T")[0];
    const matchFrom = !fromDate || aDate >= fromDate;
    const matchTo = !toDate || aDate <= toDate;

    return matchSearch && matchAction && matchFrom && matchTo;
  });

  return (
    <div className="p-6 max-w-7xl space-y-5">
      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative min-w-[200px] max-w-xs flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search user, details, IP..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
            data-testid="input-search"
          />
        </div>
        <Select value={actionFilter} onValueChange={setActionFilter}>
          <SelectTrigger className="w-48" data-testid="select-action-filter">
            <SelectValue placeholder="All Actions" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Actions</SelectItem>
            {actionTypes.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground whitespace-nowrap">From</span>
          <Input type="date" className="w-36 h-9" value={fromDate} onChange={e => setFromDate(e.target.value)} data-testid="input-from-date" />
          <span className="text-xs text-muted-foreground">To</span>
          <Input type="date" className="w-36 h-9" value={toDate} onChange={e => setToDate(e.target.value)} data-testid="input-to-date" />
        </div>
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/30">
                {["TIMESTAMP", "USER", "ACTION", "DETAILS", "IP ADDRESS", "STATUS"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? Array.from({ length: 5 }).map((_, i) => (
                <tr key={i} className="border-b">{Array.from({ length: 6 }).map((_, j) => <td key={j} className="px-4 py-4"><Skeleton className="h-4 w-24" /></td>)}</tr>
              )) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center">
                    <ActivityIcon className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No activity found.</p>
                  </td>
                </tr>
              ) : filtered.map((a, i) => (
                <tr key={a.id} className="border-b last:border-0 hover:bg-muted/10 transition-colors" data-testid={`row-activity-${a.id}`}>
                  <td className="px-4 py-3 text-muted-foreground text-xs whitespace-nowrap">{fmt(a.timestamp)}</td>
                  <td className="px-4 py-3 font-medium">{a.username}</td>
                  <td className="px-4 py-3">{actionBadge(a.action)}</td>
                  <td className="px-4 py-3 text-muted-foreground max-w-[220px] truncate">{a.details || "—"}</td>
                  <td className="px-4 py-3">
                    <span className="font-mono text-xs text-muted-foreground">{a.ipAddress || "—"}</span>
                  </td>
                  <td className="px-4 py-3">
                    {a.success
                      ? <span className="flex items-center gap-1 text-xs text-emerald-600"><CheckCircle2 className="w-3.5 h-3.5" /> Success</span>
                      : <span className="flex items-center gap-1 text-xs text-red-500"><XCircle className="w-3.5 h-3.5" /> Failed</span>
                    }
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!isLoading && (
            <p className="px-4 py-2 text-xs text-muted-foreground border-t">
              Showing {filtered.length} of {activities.length} entries
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
