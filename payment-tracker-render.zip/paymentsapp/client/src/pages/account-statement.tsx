import { useQuery } from "@tanstack/react-query";
import type { Payment, PaymentTxn, Purchase } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpen, TrendingUp, TrendingDown, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { queryClient } from "@/lib/queryClient";

const inr = (n: number) => "₹" + Math.abs(n).toLocaleString("en-IN");

const statusBadge = (s: string) => {
  const map: Record<string, string> = {
    Pending: "bg-amber-100 text-amber-700 border-amber-200",
    ManagerApproved: "bg-blue-100 text-blue-700 border-blue-200",
    ManagerRejected: "bg-red-100 text-red-700 border-red-200",
    CEORejected: "bg-red-100 text-red-700 border-red-200",
    Approved: "bg-emerald-100 text-emerald-700 border-emerald-200",
  };
  const labels: Record<string, string> = { ManagerApproved: "Mgr Approved", ManagerRejected: "Mgr Rejected", CEORejected: "CEO Rejected" };
  return <Badge className={`${map[s] ?? "bg-gray-100 text-gray-700"} text-xs`}>{labels[s] ?? s}</Badge>;
};

export default function AccountStatement() {
  const { data: payments = [], isLoading: pLoad } = useQuery<Payment[]>({ queryKey: ["/api/payments"] });
  const { data: txns = [], isLoading: tLoad } = useQuery<PaymentTxn[]>({ queryKey: ["/api/payment-txns"] });
  const { data: purchases = [], isLoading: purLoad } = useQuery<Purchase[]>({ queryKey: ["/api/purchases"] });

  const isLoading = pLoad || tLoad || purLoad;

  const totalOutstanding = payments.reduce((s, p) => s + p.totalOutstanding, 0);
  const totalPaid = txns.filter(t => t.approvalStatus === "Approved").reduce((s, t) => s + t.amount, 0);
  const totalPurchases = purchases.reduce((s, p) => s + p.amount, 0);
  const totalEntries = txns.length + purchases.length;

  function refresh() {
    queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
    queryClient.invalidateQueries({ queryKey: ["/api/payment-txns"] });
    queryClient.invalidateQueries({ queryKey: ["/api/purchases"] });
  }

  return (
    <div className="p-6 max-w-6xl space-y-5">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Payment name-wise ledger — purchases add to outstanding, approved payments reduce it</p>
        <Button variant="outline" size="sm" onClick={refresh} className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" />Refresh</Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "TOTAL OUTSTANDING", value: inr(totalOutstanding), color: "text-primary" },
          { label: "TOTAL PURCHASES", value: inr(totalPurchases), color: "text-orange-600" },
          { label: "TOTAL PAID (APPROVED)", value: inr(totalPaid), color: "text-emerald-600" },
          { label: "TOTAL ENTRIES", value: totalEntries, color: "text-foreground" },
        ].map(c => (
          <div key={c.label} className="bg-card rounded-xl border p-4 shadow-sm">
            <p className="text-xs font-semibold text-muted-foreground tracking-wide mb-1">{c.label}</p>
            {isLoading ? <Skeleton className="h-7 w-24" /> : <p className={`text-xl font-bold ${c.color}`}>{c.value}</p>}
          </div>
        ))}
      </div>

      {/* Per-Payment Ledger */}
      {isLoading ? (
        <div className="space-y-4">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-40 w-full rounded-xl" />)}</div>
      ) : payments.length === 0 ? (
        <div className="bg-card rounded-xl border p-12 text-center text-muted-foreground">No payment accounts.</div>
      ) : payments.map(p => {
        const pTxns = txns.filter(t => t.paymentId === p.id);
        const pPurs = purchases.filter(pur => pur.paymentId === p.id);
        
        // Build combined ledger sorted by date
        type LedgerRow = { date: string; narration: string; debit: number | null; credit: number | null; type: string; status?: string; comment?: string | null; balance: number; };
        const rows: LedgerRow[] = [];
        let balance = p.totalOutstanding;

        // Combine and sort
        const all = [
          ...pTxns.map(t => ({ date: t.date, narration: t.narration, amount: t.amount, type: "payment", status: t.approvalStatus, comment: t.approvalComment, isDebit: true, affectsBalance: t.approvalStatus === "Approved" })),
          ...pPurs.map(pur => ({ date: pur.date, narration: pur.narration, amount: pur.amount, type: "purchase", status: "Saved", comment: null, isDebit: false, affectsBalance: true })),
        ].sort((a, b) => a.date.localeCompare(b.date));

        for (const item of all) {
          if (item.affectsBalance) {
            if (item.isDebit) balance -= item.amount;
            else balance += item.amount;
          }
          rows.push({
            date: item.date,
            narration: item.narration,
            debit: item.isDebit ? item.amount : null,
            credit: !item.isDebit ? item.amount : null,
            type: item.type,
            status: item.status,
            comment: item.comment,
            balance,
          });
        }

        return (
          <div key={p.id} className="bg-card rounded-xl border shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b bg-muted/20 flex items-start justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <BookOpen className="w-4 h-4 text-primary" />
                <div>
                  <p className="font-semibold text-sm">{p.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-xs">{p.actionPoint}</Badge>
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs">{p.costCenter}</Badge>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Current Outstanding</p>
                <p className="text-lg font-bold text-primary">₹{p.totalOutstanding.toLocaleString("en-IN")}</p>
              </div>
            </div>
            {rows.length === 0 ? (
              <p className="px-5 py-6 text-sm text-muted-foreground text-center">No transactions yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/10">
                      {["DATE","NARRATION","DEBIT (PAYMENT)","CREDIT (PURCHASE)","TYPE / STATUS","BALANCE"].map(h => (
                        <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row, i) => (
                      <tr key={i} className="border-b last:border-0 hover:bg-muted/10">
                        <td className="px-4 py-3 text-muted-foreground text-xs whitespace-nowrap">{row.date}</td>
                        <td className="px-4 py-3 max-w-[180px]">
                          <p className="truncate">{row.narration}</p>
                          {row.comment && <p className="text-xs text-muted-foreground italic truncate">{row.comment}</p>}
                        </td>
                        <td className="px-4 py-3">
                          {row.debit != null ? (
                            <span className="flex items-center gap-1 text-emerald-600 font-semibold">
                              <TrendingDown className="w-3.5 h-3.5" />{inr(row.debit)}
                            </span>
                          ) : "—"}
                        </td>
                        <td className="px-4 py-3">
                          {row.credit != null ? (
                            <span className="flex items-center gap-1 text-orange-600 font-semibold">
                              <TrendingUp className="w-3.5 h-3.5" />{inr(row.credit)}
                            </span>
                          ) : "—"}
                        </td>
                        <td className="px-4 py-3">
                          {row.status ? statusBadge(row.status) : <Badge variant="outline" className="text-xs">{row.type}</Badge>}
                        </td>
                        <td className="px-4 py-3 font-bold text-right">₹{row.balance.toLocaleString("en-IN")}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
