import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, desc, and, or, like, sql } from "drizzle-orm";
import {
  users, payments, paymentTxns, purchases, bankBalances, activityLog, dropdownOptions, sessions
} from "@shared/schema";
import type {
  User, InsertUser, Payment, InsertPayment,
  PaymentTxn, InsertPaymentTxn, Purchase, InsertPurchase,
  BankBalance, InsertBankBalance, Activity, InsertActivity
} from "@shared/schema";

const DB_PATH = process.env.NODE_ENV === "production" && process.env.RENDER
  ? "/data/data.db"
  : "data.db";
const sqlite = new Database(DB_PATH);
sqlite.pragma("journal_mode = WAL");
export const db = drizzle(sqlite);

export const storage = {
  // ── USERS ──────────────────────────────────────────────────────────────────
  getUserById(id: number): User | undefined {
    return db.select().from(users).where(eq(users.id, id)).get();
  },
  getUserByUsername(username: string): User | undefined {
    return db.select().from(users).where(eq(users.username, username)).get();
  },
  createUser(data: InsertUser): User {
    return db.insert(users).values(data).returning().get();
  },

  // Sessions
  createSession(token: string, userId: number, createdAt: string) {
    return db.insert(sessions).values({ token, userId, createdAt }).returning().get();
  },
  getSession(token: string) {
    return db.select().from(sessions).where(eq(sessions.token, token)).get();
  },
  deleteSession(token: string) {
    db.delete(sessions).where(eq(sessions.token, token)).run();
  },
  deleteOldSessions() {
    // Keep sessions for 30 days
    const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    db.delete(sessions).where(sql`created_at < ${cutoff}`).run();
  },
  updateUser(id: number, data: Partial<InsertUser>): User | undefined {
    return db.update(users).set(data).where(eq(users.id, id)).returning().get();
  },

  // ── PAYMENTS ───────────────────────────────────────────────────────────────
  getAllPayments(): Payment[] {
    return db.select().from(payments).all();
  },
  getPaymentById(id: number): Payment | undefined {
    return db.select().from(payments).where(eq(payments.id, id)).get();
  },
  createPayment(data: InsertPayment): Payment {
    return db.insert(payments).values(data).returning().get();
  },
  updatePayment(id: number, data: Partial<InsertPayment>): Payment | undefined {
    return db.update(payments).set(data).where(eq(payments.id, id)).returning().get();
  },
  deletePayment(id: number): void {
    db.delete(payments).where(eq(payments.id, id)).run();
  },

  // ── PAYMENT TRANSACTIONS ───────────────────────────────────────────────────
  getAllPaymentTxns(): PaymentTxn[] {
    return db.select().from(paymentTxns).orderBy(desc(paymentTxns.id)).all();
  },
  getPaymentTxnsByStatus(status: string): PaymentTxn[] {
    return db.select().from(paymentTxns).where(eq(paymentTxns.approvalStatus, status)).orderBy(desc(paymentTxns.id)).all();
  },
  getPaymentTxnById(id: number): PaymentTxn | undefined {
    return db.select().from(paymentTxns).where(eq(paymentTxns.id, id)).get();
  },
  createPaymentTxn(data: InsertPaymentTxn): PaymentTxn {
    return db.insert(paymentTxns).values(data).returning().get();
  },
  updatePaymentTxnStatus(id: number, status: string, comment?: string, reviewedField?: "manager" | "ceo"): PaymentTxn | undefined {
    const now = new Date().toISOString();
    const update: any = { approvalStatus: status, approvalComment: comment ?? null };
    if (reviewedField === "manager") update.managerReviewedAt = now;
    if (reviewedField === "ceo") update.ceoReviewedAt = now;
    return db.update(paymentTxns).set(update).where(eq(paymentTxns.id, id)).returning().get();
  },

  // ── PURCHASES ──────────────────────────────────────────────────────────────
  getAllPurchases(): Purchase[] {
    return db.select().from(purchases).orderBy(desc(purchases.id)).all();
  },
  createPurchase(data: InsertPurchase): Purchase {
    return db.insert(purchases).values(data).returning().get();
  },

  // ── BANK BALANCES ──────────────────────────────────────────────────────────
  getAllBankBalances(): BankBalance[] {
    return db.select().from(bankBalances).all();
  },
  getBankByName(name: string): BankBalance | undefined {
    return db.select().from(bankBalances).where(eq(bankBalances.bankName, name)).get();
  },
  upsertBankBalance(bankName: string, amount: number, date: string, updatedBy: string): BankBalance {
    const existing = storage.getBankByName(bankName);
    const now = new Date().toISOString();
    if (existing) {
      return db.update(bankBalances).set({ amount, date, updatedAt: now, updatedBy }).where(eq(bankBalances.bankName, bankName)).returning().get()!;
    }
    return db.insert(bankBalances).values({ bankName, amount, date, updatedAt: now, updatedBy }).returning().get();
  },

  // ── ACTIVITY LOG ───────────────────────────────────────────────────────────
  getActivityLog(limit = 200): Activity[] {
    return db.select().from(activityLog).orderBy(desc(activityLog.id)).limit(limit).all();
  },
  logActivity(data: InsertActivity): Activity {
    return db.insert(activityLog).values(data).returning().get();
  },

  // ── DROPDOWN OPTIONS ───────────────────────────────────────────────────────
  getDropdownOptions(type: string): string[] {
    return db.select().from(dropdownOptions).where(eq(dropdownOptions.type, type)).all().map(r => r.value);
  },
  addDropdownOption(type: string, value: string): void {
    const exists = db.select().from(dropdownOptions).where(and(eq(dropdownOptions.type, type), eq(dropdownOptions.value, value))).get();
    if (!exists) db.insert(dropdownOptions).values({ type, value }).run();
  },

  // ── SEED ───────────────────────────────────────────────────────────────────
  seed(): void {
    const now = new Date().toISOString();
    // Seed dropdown options
    const costCenters = ["Kalyani Nagar", "Baner", "Andheri", "Kharadi", "Pune HO"];
    const actionPoints = ["Outlet Rent", "Salary-KN", "Salary-BN", "Vendor Payment", "Utilities", "Marketing"];
    for (const cc of costCenters) storage.addDropdownOption("costCenter", cc);
    for (const ap of actionPoints) storage.addDropdownOption("actionPoint", ap);

    // Seed bank balances
    const today = new Date().toISOString().split("T")[0];
    if (!storage.getBankByName("DSR")) {
      storage.upsertBankBalance("DSR", 0, today, "system");
    }
    if (!storage.getBankByName("Maaching")) {
      storage.upsertBankBalance("Maaching", 0, today, "system");
    }

    // Seed sample payments if none exist
    if (storage.getAllPayments().length === 0) {
      storage.createPayment({ name: "Rent-KN", totalOutstanding: 10000, costCenter: "Kalyani Nagar", actionPoint: "Outlet Rent", dueDay: 10, amount: 10000, narration: "", openingBalanceUpdatedAt: now, createdAt: now });
      storage.createPayment({ name: "Rent-Sunanda Nagarmoti", totalOutstanding: 42000, costCenter: "Baner", actionPoint: "Outlet Rent", dueDay: 11, amount: 42000, narration: "", openingBalanceUpdatedAt: now, createdAt: now });
      storage.createPayment({ name: "Salary Kalyani Nagar", totalOutstanding: 230000, costCenter: "Kalyani Nagar", actionPoint: "Salary-KN", dueDay: 24, amount: 230000, narration: "", openingBalanceUpdatedAt: now, createdAt: now });
    }
  }
};
