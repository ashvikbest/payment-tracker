import type { Express } from "express";
import { type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

const REGISTRATION_PASSKEY = "Ashvik";
const now = () => new Date().toISOString();
const today = () => new Date().toISOString().split("T")[0];

function getIp(req: any): string {
  return (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket?.remoteAddress || "unknown";
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {

  // ── SEED ─────────────────────────────────────────────────────────────────
  storage.seed();

  // ── AUTH ──────────────────────────────────────────────────────────────────
  app.post("/api/auth/register", (req, res) => {
    const schema = z.object({
      username: z.string().min(1),
      password: z.string().min(6),
      role: z.enum(["account", "manager", "ceo"]),
      passkey: z.string(),
    });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Invalid input" });
    const { username, password, role, passkey } = parsed.data;

    if (passkey !== REGISTRATION_PASSKEY) {
      storage.logActivity({ username, action: "Register", details: "Invalid passkey", ipAddress: getIp(req), success: false, timestamp: now() });
      return res.status(403).json({ message: "Incorrect passkey. Please contact your administrator." });
    }
    if (storage.getUserByUsername(username)) {
      return res.status(409).json({ message: "Username already taken." });
    }
    const user = storage.createUser({ username, password, role, createdAt: now(), lastLoginAt: null, lastLoginIp: null });
    storage.logActivity({ username, action: "Register", details: `Registered as ${role}`, ipAddress: getIp(req), success: true, timestamp: now() });
    res.status(201).json({ id: user.id, username: user.username, role: user.role });
  });

  app.post("/api/auth/login", (req, res) => {
    const schema = z.object({ username: z.string(), password: z.string() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Invalid input" });
    const { username, password } = parsed.data;
    const user = storage.getUserByUsername(username);
    if (!user || user.password !== password) {
      storage.logActivity({ username, action: "Login", details: "Invalid credentials", ipAddress: getIp(req), success: false, timestamp: now() });
      return res.status(401).json({ message: "Invalid credentials. Please try again." });
    }
    storage.updateUser(user.id, { lastLoginAt: now(), lastLoginIp: getIp(req) });
    storage.logActivity({ username, action: "Login", details: `Logged in as ${user.role}`, ipAddress: getIp(req), success: true, timestamp: now() });
    // Issue persistent session token
    const token = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2) + Date.now().toString(36);
    storage.createSession(token, user.id, now());
    res.json({ id: user.id, username: user.username, role: user.role, token });
  });

  // Validate existing session token (used on app startup)
  app.get("/api/auth/me", (req, res) => {
    const token = req.headers["x-session-token"] as string;
    if (!token) return res.status(401).json({ message: "No token" });
    const session = storage.getSession(token);
    if (!session) return res.status(401).json({ message: "Invalid or expired session" });
    const user = storage.getUserById(session.userId);
    if (!user) return res.status(401).json({ message: "User not found" });
    res.json({ id: user.id, username: user.username, role: user.role, token });
  });

  // Logout — delete session
  app.post("/api/auth/logout", (req, res) => {
    const token = req.headers["x-session-token"] as string;
    if (token) storage.deleteSession(token);
    res.json({ success: true });
  });

  app.post("/api/auth/reset-password", (req, res) => {
    const schema = z.object({ username: z.string(), passkey: z.string(), newPassword: z.string().min(6) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Invalid input" });
    const { username, passkey, newPassword } = parsed.data;
    if (passkey !== REGISTRATION_PASSKEY) {
      return res.status(403).json({ message: "Incorrect passkey." });
    }
    const user = storage.getUserByUsername(username);
    if (!user) return res.status(404).json({ message: "User not found." });
    storage.updateUser(user.id, { password: newPassword });
    storage.logActivity({ username, action: "Reset Password", details: "Password reset", ipAddress: getIp(req), success: true, timestamp: now() });
    res.json({ message: "Password reset successful." });
  });

  // ── PAYMENTS ──────────────────────────────────────────────────────────────
  app.get("/api/payments", (_req, res) => res.json(storage.getAllPayments()));

  app.post("/api/payments", (req, res) => {
    const schema = z.object({
      name: z.string().min(1),
      totalOutstanding: z.number(),
      costCenter: z.string().min(1),
      actionPoint: z.string().min(1),
      dueDay: z.number().min(1).max(31),
      amount: z.number(),
      narration: z.string().optional(),
    });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json(parsed.error);
    const p = storage.createPayment({ ...parsed.data, narration: parsed.data.narration ?? "", openingBalanceUpdatedAt: now(), createdAt: now() });
    storage.logActivity({ username: req.body.username ?? "system", action: "Create Payment", details: `Created: ${p.name}`, ipAddress: getIp(req), success: true, timestamp: now() });
    // Auto-add cost center and action point to dropdown options
    storage.addDropdownOption("costCenter", p.costCenter);
    storage.addDropdownOption("actionPoint", p.actionPoint);
    res.status(201).json(p);
  });

  app.patch("/api/payments/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const p = storage.updatePayment(id, req.body);
    if (!p) return res.status(404).json({ message: "Not found" });
    storage.logActivity({ username: req.body.username ?? "system", action: "Update Payment", details: `Updated: ${p.name}`, ipAddress: getIp(req), success: true, timestamp: now() });
    res.json(p);
  });

  app.delete("/api/payments/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const p = storage.getPaymentById(id);
    if (!p) return res.status(404).json({ message: "Not found" });
    storage.deletePayment(id);
    storage.logActivity({ username: (req.query.username as string) ?? "system", action: "Delete Payment", details: `Deleted: ${p.name}`, ipAddress: getIp(req), success: true, timestamp: now() });
    res.json({ success: true });
  });

  // ── PAYMENT TRANSACTIONS ───────────────────────────────────────────────────
  app.get("/api/payment-txns", (_req, res) => res.json(storage.getAllPaymentTxns()));

  app.post("/api/payment-txns", (req, res) => {
    const schema = z.object({
      paymentId: z.number(),
      paymentName: z.string(),
      costCenter: z.string(),
      amount: z.number().min(1),
      date: z.string(),
      narration: z.string().min(1),
      submittedBy: z.string(),
    });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json(parsed.error);
    const txn = storage.createPaymentTxn({ ...parsed.data, approvalStatus: "Pending", approvalComment: null, managerReviewedAt: null, ceoReviewedAt: null, createdAt: now() });
    storage.logActivity({ username: parsed.data.submittedBy, action: "Submit Payment", details: `Submitted ₹${parsed.data.amount} for ${parsed.data.paymentName}`, ipAddress: getIp(req), success: true, timestamp: now() });
    res.status(201).json(txn);
  });

  // Manager approve/reject
  app.patch("/api/payment-txns/:id/manager", (req, res) => {
    const id = parseInt(req.params.id);
    const schema = z.object({ action: z.enum(["approve", "reject"]), comment: z.string().optional(), username: z.string() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json(parsed.error);
    const status = parsed.data.action === "approve" ? "ManagerApproved" : "ManagerRejected";
    const txn = storage.updatePaymentTxnStatus(id, status, parsed.data.comment, "manager");
    if (!txn) return res.status(404).json({ message: "Not found" });
    storage.logActivity({ username: parsed.data.username, action: parsed.data.action === "approve" ? "Manager Approved" : "Manager Rejected", details: `Txn #${id}: ${txn.paymentName}`, ipAddress: getIp(req), success: true, timestamp: now() });
    res.json(txn);
  });

  // CEO approve/reject
  app.patch("/api/payment-txns/:id/ceo", (req, res) => {
    const id = parseInt(req.params.id);
    const schema = z.object({ action: z.enum(["approve", "reject"]), comment: z.string().optional(), username: z.string() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json(parsed.error);
    const status = parsed.data.action === "approve" ? "Approved" : "CEORejected";

    // Fetch txn BEFORE updating so we have amount + paymentId
    const existing = storage.getPaymentTxnById(id);
    if (!existing) return res.status(404).json({ message: "Not found" });

    const txn = storage.updatePaymentTxnStatus(id, status, parsed.data.comment, "ceo");
    if (!txn) return res.status(404).json({ message: "Not found" });

    // On approval: deduct the paid amount from the parent payment's totalOutstanding
    if (parsed.data.action === "approve") {
      const payment = storage.getPaymentById(existing.paymentId);
      if (payment) {
        const newOutstanding = Math.max(0, payment.totalOutstanding - existing.amount);
        storage.updatePayment(payment.id, { totalOutstanding: newOutstanding });
      }
    }

    storage.logActivity({ username: parsed.data.username, action: parsed.data.action === "approve" ? "CEO Approved" : "CEO Rejected", details: `Txn #${id}: ${txn.paymentName} ₹${existing.amount}`, ipAddress: getIp(req), success: true, timestamp: now() });
    res.json(txn);
  });

  // ── PURCHASES ──────────────────────────────────────────────────────────────
  app.get("/api/purchases", (_req, res) => res.json(storage.getAllPurchases()));

  app.post("/api/purchases", (req, res) => {
    const schema = z.object({
      paymentId: z.number(),
      purchaseName: z.string(),
      amount: z.number().min(1),
      date: z.string(),
      narration: z.string().min(1),
      submittedBy: z.string(),
    });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json(parsed.error);
    const pur = storage.createPurchase({ ...parsed.data, createdAt: now() });
    storage.logActivity({ username: parsed.data.submittedBy, action: "Submit Purchase", details: `₹${parsed.data.amount} purchase for ${parsed.data.purchaseName}`, ipAddress: getIp(req), success: true, timestamp: now() });
    res.status(201).json(pur);
  });

  // ── BANK BALANCES ──────────────────────────────────────────────────────────
  app.get("/api/bank-balances", (_req, res) => res.json(storage.getAllBankBalances()));

  app.post("/api/bank-balances", (req, res) => {
    const schema = z.object({ bankName: z.string(), amount: z.number(), date: z.string(), updatedBy: z.string().optional() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json(parsed.error);
    const bal = storage.upsertBankBalance(parsed.data.bankName, parsed.data.amount, parsed.data.date, parsed.data.updatedBy ?? "system");
    storage.logActivity({ username: parsed.data.updatedBy ?? "system", action: "Update Bank Balance", details: `${parsed.data.bankName}: ₹${parsed.data.amount}`, ipAddress: getIp(req), success: true, timestamp: now() });
    res.json(bal);
  });

  // ── ACTIVITY LOG ───────────────────────────────────────────────────────────
  app.get("/api/activity", (_req, res) => res.json(storage.getActivityLog()));

  // ── DROPDOWN OPTIONS ───────────────────────────────────────────────────────
  app.get("/api/dropdown/:type", (req, res) => {
    res.json(storage.getDropdownOptions(req.params.type));
  });

  app.post("/api/dropdown/:type", (req, res) => {
    const { value } = req.body;
    if (!value) return res.status(400).json({ message: "value required" });
    storage.addDropdownOption(req.params.type, value);
    res.json({ success: true });
  });

  // ── EXCEL REPORT ───────────────────────────────────────────────────────────
  app.get("/api/reports/excel", async (req, res) => {
    try {
      const ExcelJS = require("exceljs");
      const { from, to, paymentName, costCenter, bankName, actionType } = req.query as Record<string, string>;

      const getBankForCC = (cc: string) => cc.toLowerCase().includes("andheri") ? "Maaching" : "DSR";

      let rows = storage.getAllPaymentTxns();

      // Apply filters
      if (paymentName && paymentName !== "all") rows = rows.filter(t => t.paymentName === paymentName);
      if (from)         rows = rows.filter(t => t.date.slice(0, 10) >= from);
      if (to)           rows = rows.filter(t => t.date.slice(0, 10) <= to);
      if (costCenter && costCenter !== "all") rows = rows.filter(t => t.costCenter === costCenter);
      if (bankName && bankName !== "all") rows = rows.filter(t => getBankForCC(t.costCenter) === bankName);
      if (actionType && actionType !== "all") rows = rows.filter(t => t.approvalStatus === actionType);
      rows = rows.sort((a, b) => b.date.localeCompare(a.date));

      const wb = new ExcelJS.Workbook();
      wb.creator = "Payment Tracker";
      wb.created = new Date();

      // ── Sheet 1: Payment Report ─────────────────────────────────────────────
      const ws = wb.addWorksheet("Payment Report");
      ws.columns = [
        { width: 5 }, { width: 28 }, { width: 20 }, { width: 16 },
        { width: 16 }, { width: 14 }, { width: 32 }, { width: 18 },
        { width: 22 }, { width: 22 }, { width: 18 },
      ];

      // Title
      ws.mergeCells("A1:K1");
      const title = ws.getCell("A1");
      const filterParts: string[] = [];
      if (paymentName && paymentName !== "all") filterParts.push(`Payment: ${paymentName}`);
      if (from || to) filterParts.push(`Date: ${from || "start"} → ${to || "end"}`);
      if (costCenter && costCenter !== "all") filterParts.push(`Centre: ${costCenter}`);
      if (bankName && bankName !== "all") filterParts.push(`Bank: ${bankName}`);
      if (actionType && actionType !== "all") filterParts.push(`Status: ${actionType}`);
      title.value = "PAYMENT TRACKER — PAYMENT REPORT";
      title.font = { bold: true, size: 16, color: { argb: "FFFFFFFF" }, name: "Calibri" };
      title.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1E3A5F" } };
      title.alignment = { horizontal: "center", vertical: "middle" };
      ws.getRow(1).height = 40;

      ws.mergeCells("A2:K2");
      const sub = ws.getCell("A2");
      sub.value = `Generated: ${new Date().toLocaleString("en-IN")}   ${filterParts.length ? "| Filters: " + filterParts.join("  •  ") : "| All records"}`;
      sub.font = { size: 9, italic: true, color: { argb: "FFCCDDEE" } };
      sub.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1E3A5F" } };
      sub.alignment = { horizontal: "center", vertical: "middle" };
      ws.getRow(2).height = 18;
      ws.addRow([]);

      // Header row
      const statusColors: Record<string, { bg: string; fg: string }> = {
        Pending:         { bg: "FFFEF3C7", fg: "FFD97706" },
        ManagerApproved: { bg: "FFDBEAFE", fg: "FF1D4ED8" },
        ManagerRejected: { bg: "FFFEE2E2", fg: "FFDC2626" },
        Approved:        { bg: "FFD1FAE5", fg: "FF059669" },
        CEORejected:     { bg: "FFFEE2E2", fg: "FFDC2626" },
      };

      const hdr = ws.addRow(["#", "Payment Name", "Cost Centre", "Bank", "Amount (₹)", "Date", "Narration", "Submitted By", "Mgr Reviewed At", "CEO Reviewed At", "Status"]);
      hdr.height = 28;
      hdr.eachCell(cell => {
        cell.font = { bold: true, size: 11, color: { argb: "FFFFFFFF" }, name: "Calibri" };
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF2563EB" } };
        cell.alignment = { horizontal: "center", vertical: "middle" };
        cell.border = { bottom: { style: "medium", color: { argb: "FF1D4ED8" } } };
      });

      // Data rows
      rows.forEach((t, i) => {
        const isEven = i % 2 === 1;
        const bg = isEven ? "FFF1F5F9" : "FFFFFFFF";
        const bank = getBankForCC(t.costCenter);
        const sc = statusColors[t.approvalStatus] ?? { bg: "FFFFFFFF", fg: "FF374151" };
        const fmtTs = (ts: string | null) => ts ? new Date(ts).toLocaleString("en-IN") : "—";

        const row = ws.addRow([
          i + 1, t.paymentName, t.costCenter, `${bank} Bank`,
          t.amount, t.date, t.narration, t.submittedBy,
          fmtTs(t.managerReviewedAt), fmtTs(t.ceoReviewedAt), t.approvalStatus,
        ]);
        row.height = 22;
        row.eachCell((cell, col) => {
          cell.font = { size: 10, name: "Calibri", color: { argb: "FF1F2937" } };
          cell.alignment = { vertical: "middle" };
          cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: bg } };
          cell.border = { bottom: { style: "thin", color: { argb: "FFE2E8F0" } } };
          if (col === 1)  { cell.alignment = { horizontal: "center", vertical: "middle" }; cell.font = { size: 9, color: { argb: "FF6B7280" } }; }
          if (col === 2)  { cell.font = { bold: true, size: 10, name: "Calibri", color: { argb: "FF111827" } }; }
          if (col === 3)  { cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: isEven ? "FFDBEAFE" : "FFEFF6FF" } }; cell.font = { size: 10, color: { argb: "FF1D4ED8" } }; cell.alignment = { horizontal: "center", vertical: "middle" }; }
          if (col === 4)  { cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: bank === "Maaching" ? "FFF5F3FF" : "FFF0FDF4" } }; cell.font = { bold: true, size: 10, color: { argb: bank === "Maaching" ? "FF7C3AED" : "FF059669" } }; cell.alignment = { horizontal: "center", vertical: "middle" }; }
          if (col === 5)  { cell.numFmt = "#,##0.00"; cell.font = { bold: true, size: 10, color: { argb: "FF1D4ED8" } }; cell.alignment = { horizontal: "right", vertical: "middle" }; }
          if (col === 6)  { cell.alignment = { horizontal: "center", vertical: "middle" }; }
          if (col === 7)  { cell.font = { size: 9, italic: true, color: { argb: "FF6B7280" } }; }
          if (col >= 8 && col <= 10) { cell.font = { size: 9, color: { argb: "FF6B7280" } }; cell.alignment = { horizontal: "center", vertical: "middle" }; }
          if (col === 11) { cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: sc.bg } }; cell.font = { bold: true, size: 10, color: { argb: sc.fg } }; cell.alignment = { horizontal: "center", vertical: "middle" }; }
        });
      });

      // Totals row
      const total = rows.reduce((s, t) => s + t.amount, 0);
      const tot = ws.addRow(["", `TOTAL (${rows.length} transactions)`, "", "", total, "", "", "", "", "", ""]);
      tot.height = 26;
      tot.eachCell((cell, col) => {
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1E3A5F" } };
        cell.font = { bold: true, size: 11, color: { argb: "FFFFFFFF" } };
        cell.alignment = { vertical: "middle" };
        cell.border = { top: { style: "medium", color: { argb: "FF2563EB" } } };
        if (col === 2) cell.alignment = { horizontal: "left", vertical: "middle" };
        if (col === 5) { cell.numFmt = "#,##0.00"; cell.alignment = { horizontal: "right", vertical: "middle" }; }
      });

      ws.autoFilter = { from: "A4", to: "K4" };
      ws.views = [{ state: "frozen", xSplit: 0, ySplit: 4 }];

      // ── Sheet 2: Summary ────────────────────────────────────────────────────
      const ws2 = wb.addWorksheet("Summary");
      ws2.columns = [{ width: 28 }, { width: 14 }, { width: 18 }];
      ws2.mergeCells("A1:C1");
      const s2t = ws2.getCell("A1"); s2t.value = "PAYMENT SUMMARY";
      s2t.font = { bold: true, size: 14, color: { argb: "FFFFFFFF" } };
      s2t.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1E3A5F" } };
      s2t.alignment = { horizontal: "center", vertical: "middle" }; ws2.getRow(1).height = 36;
      ws2.addRow([]);
      const s2h = ws2.addRow(["Status", "Count", "Total Amount (₹)"]);
      s2h.height = 24;
      s2h.eachCell(c => { c.font = { bold: true, size: 11, color: { argb: "FFFFFFFF" } }; c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF2563EB" } }; c.alignment = { horizontal: "center", vertical: "middle" }; });
      const statuses = [
        { label: "Pending", key: "Pending" },
        { label: "Manager Approved", key: "ManagerApproved" },
        { label: "Approved (CEO)", key: "Approved" },
        { label: "Manager Rejected", key: "ManagerRejected" },
        { label: "CEO Rejected", key: "CEORejected" },
      ];
      statuses.forEach(({ label, key }) => {
        const match = rows.filter(r => r.approvalStatus === key);
        const sc2 = statusColors[key] ?? { bg: "FFFFFFFF", fg: "FF374151" };
        const r2 = ws2.addRow([label, match.length, match.reduce((s, t) => s + t.amount, 0)]);
        r2.height = 22;
        r2.eachCell((cell, col) => {
          cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: sc2.bg } };
          cell.font = { size: 11, bold: col > 1, color: { argb: sc2.fg } };
          cell.alignment = { horizontal: col === 1 ? "left" : "center", vertical: "middle" };
          cell.border = { bottom: { style: "thin", color: { argb: "FFE2E8F0" } } };
          if (col === 3) { cell.numFmt = "#,##0.00"; cell.alignment = { horizontal: "right", vertical: "middle" }; }
        });
      });
      const gt = ws2.addRow(["GRAND TOTAL", rows.length, total]);
      gt.height = 26;
      gt.eachCell((cell, col) => {
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1E3A5F" } };
        cell.font = { bold: true, size: 12, color: { argb: "FFFFFFFF" } };
        cell.alignment = { horizontal: col === 1 ? "left" : "center", vertical: "middle" };
        if (col === 3) { cell.numFmt = "#,##0.00"; cell.alignment = { horizontal: "right", vertical: "middle" }; }
      });

      // ── Send file ───────────────────────────────────────────────────────────
      const date = new Date().toISOString().split("T")[0];
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", `attachment; filename=payment-report-${date}.xlsx`);
      await wb.xlsx.write(res);
      res.end();
    } catch (err: any) {
      console.error("Excel generation error:", err);
      res.status(500).json({ message: err.message });
    }
  });

  return httpServer;
}
