import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ── USERS ─────────────────────────────────────────────────────────────────────
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("account"), // account | manager | ceo
  createdAt: text("created_at").notNull(),
  lastLoginAt: text("last_login_at"),
  lastLoginIp: text("last_login_ip"),
});
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// ── PAYMENTS (master accounts) ────────────────────────────────────────────────
export const payments = sqliteTable("payments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  totalOutstanding: real("total_outstanding").notNull().default(0),
  costCenter: text("cost_center").notNull(),
  actionPoint: text("action_point").notNull(),
  dueDay: integer("due_day").notNull().default(1),
  amount: real("amount").notNull().default(0),
  narration: text("narration").default(""),
  openingBalanceUpdatedAt: text("opening_balance_updated_at"),
  createdAt: text("created_at").notNull(),
});
export const insertPaymentSchema = createInsertSchema(payments).omit({ id: true });
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;

// ── PAYMENT TRANSACTIONS ──────────────────────────────────────────────────────
// Payments submitted by Account users, approved by Manager then CEO
export const paymentTxns = sqliteTable("payment_txns", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  paymentId: integer("payment_id").notNull(),
  paymentName: text("payment_name").notNull(),
  costCenter: text("cost_center").notNull(),
  amount: real("amount").notNull(),
  date: text("date").notNull(),
  narration: text("narration").notNull(),
  // Pending | ManagerApproved | ManagerRejected | CEORejected | Approved
  approvalStatus: text("approval_status").notNull().default("Pending"),
  approvalComment: text("approval_comment"),
  submittedBy: text("submitted_by").notNull(),
  managerReviewedAt: text("manager_reviewed_at"),
  ceoReviewedAt: text("ceo_reviewed_at"),
  createdAt: text("created_at").notNull(),
});
export const insertPaymentTxnSchema = createInsertSchema(paymentTxns).omit({ id: true });
export type InsertPaymentTxn = z.infer<typeof insertPaymentTxnSchema>;
export type PaymentTxn = typeof paymentTxns.$inferSelect;

// ── PURCHASES ─────────────────────────────────────────────────────────────────
// Submitted by Account role, no approval needed
export const purchases = sqliteTable("purchases", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  paymentId: integer("payment_id").notNull(),
  purchaseName: text("purchase_name").notNull(),
  amount: real("amount").notNull(),
  date: text("date").notNull(),
  narration: text("narration").notNull(),
  submittedBy: text("submitted_by").notNull(),
  createdAt: text("created_at").notNull(),
});
export const insertPurchaseSchema = createInsertSchema(purchases).omit({ id: true });
export type InsertPurchase = z.infer<typeof insertPurchaseSchema>;
export type Purchase = typeof purchases.$inferSelect;

// ── BANK BALANCES ─────────────────────────────────────────────────────────────
export const bankBalances = sqliteTable("bank_balances", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  bankName: text("bank_name").notNull().unique(), // DSR | Maaching
  amount: real("amount").notNull().default(0),
  date: text("date").notNull(),
  updatedAt: text("updated_at").notNull(),
  updatedBy: text("updated_by"),
});
export const insertBankBalanceSchema = createInsertSchema(bankBalances).omit({ id: true });
export type InsertBankBalance = z.infer<typeof insertBankBalanceSchema>;
export type BankBalance = typeof bankBalances.$inferSelect;

// ── ACTIVITY LOG ──────────────────────────────────────────────────────────────
export const activityLog = sqliteTable("activity_log", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull(),
  action: text("action").notNull(),
  details: text("details"),
  ipAddress: text("ip_address"),
  success: integer("success", { mode: "boolean" }).notNull().default(true),
  timestamp: text("timestamp").notNull(),
});
export const insertActivitySchema = createInsertSchema(activityLog).omit({ id: true });
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activityLog.$inferSelect;

// ── DROPDOWN OPTIONS ──────────────────────────────────────────────────────────
// Session tokens — persisted in DB so login survives server restarts
export const sessions = sqliteTable("sessions", {
  token:     text("token").primaryKey(),
  userId:    integer("user_id").notNull(),
  createdAt: text("created_at").notNull(),
});
export type Session = typeof sessions.$inferSelect;

export const dropdownOptions = sqliteTable("dropdown_options", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  type: text("type").notNull(), // costCenter | actionPoint
  value: text("value").notNull(),
});
